package com.sgl.smartpra.batch.flown.amadeus.etl.app.layout;

import java.util.ArrayList;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AmadeusRecordStagingEMDV1_03Layout extends FixedLengthRecordLayout{

    public AmadeusRecordStagingEMDV1_03Layout(){
    	
    	 fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("recordType",1,1));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline",2,4));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber",5,14));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("checkDigit",15,15));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber",16,16));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageType",17,17));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageEmdDate",18,25));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("manualIndicator",26,26));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usagePerformer",27,86));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageMarketingCarrierCode",87,88));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingCarrier",89,90));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd",91,95));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCodeEmd",96,100));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode",101,115));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionDocNo",116,128));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("inConnectionCouponNo",129,129));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("associationStatus",130,132));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageLocalFlightDate",133,140));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageUtcFlightDate",141,148));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageAirline",149,152));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingFlightNumber",153,157));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOperatingFlightSuffix",158,158));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageOriginCodeEmd",159,163));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDestinationCodeEmd",164,168));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("airlineCodeEmd",169,171));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("settlementAuthorizationCode",172,186));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldMarketingCarrier",187,188));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOperatingCarrier",189,190));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceSubCode",191,193));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldOriginCode",194,198));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("soldDestinationCode",199,203));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdTotalNoOfUnits",204,218));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdChargeQualifier",219,221));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdUnitQualifier",222,224));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdChargeQualifier",225,227));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ebdRatePerUnit",228,245));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponValue",246,257));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reportedFare",258,269));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfReportedFare",270,272));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("equivalentFare",273,284));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("paymentCurrency",285,287));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("agencyNumber",288,295));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issueDate",296,303));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issuingOfficeLocation",304,308));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bookingReference",309,314));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("tourCode",315,328));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("passengerName",329,368));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("reasonForIssuanceCode",369,369));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("usageDocNumber",370,409));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("coupons",410,1929));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmount",1945,1956));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonExchangeableAmtCurr",1957,1959));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmount",1960,1971));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonRefundableAmountCurr",1972,1974));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("transactionTotalAmount",1975,1986));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfTransTotalAmt",1987,1989));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("additionalCollectionTotal",1900,2001));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfAddlCollection",2002,2004));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareConstruction",2005,2354));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("fareCalcModeIndicator",2355,2357));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionRate",2358,2362));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("commissionAmount",2363,2374));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfCommissionAmount",2375,2377));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("bankersExchangeRate",2378,2389));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netFare",2390,2401));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("currencyOfNetFare",2402,2404));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("newTax",2405,3790));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationType",5177,5179));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfIdentificationNumber",5180,5214));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerAirlineCode",5219,5221));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("frequentFlyerCustomerCode",5222,5246));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalIssueInformation",5247,5316));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber1",5317,5329));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber2",5330,5342));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber3",5343,5355));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber4",5356,5368));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber5",5369,5381));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber6",5382,5394));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("originalEmdDocNumber7",5395,5407));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment",5408,5480));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment2",5481,5553));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("formOfPayment3",5554,5626));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment",5627,5699));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment2",5700,5772));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("oldFormOfPayment3",5773,5845));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("internationalSaleIndicaor",5846,5846));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("endorsementRestrictionText",5847,6476));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("ticketingModeIndicator",6477,6477));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("netRemitIndicator",6478,6478));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("nonEndorsableIndicator",6479,6479));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("presentCreditCardIndicator",6480,6480));
         fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("filler",6481,null));
         
         
         
       
    }
}
