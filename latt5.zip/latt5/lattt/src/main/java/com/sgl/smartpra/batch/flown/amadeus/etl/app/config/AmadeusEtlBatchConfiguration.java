package com.sgl.smartpra.batch.flown.amadeus.etl.app.config;

import java.util.HashMap;
import java.util.Map;

import javax.batch.runtime.StepExecution;
import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.annotation.BeforeJob;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.listener.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
@EntityScan("com.sgl.smartpra.batch.flown.amadeus.etl.app")
@EnableJpaRepositories(basePackages = "com.sgl.smartpra.batch.flown.amadeus.etl.app.repository")
@ComponentScan({ "com.sgl.smartpra.batch.flown.amadeus.etl.app" })
@EnableAutoConfiguration
public class AmadeusEtlBatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(AmadeusEtlBatchConfiguration.class);

	private static final String[] EMD = new String[] { "QR.AL.EML.D160119.T2001.PRD" };

	private static final String[] ETL = new String[] { "PRD_ETS_LIFTFILE.QR.D190106.T235144_V1" };

	private static final String EMD_LIFT = "QR.AL.EML.D160119.T2001.PRD";

	private static final String ETL_LIFT = "PRD_ETS_LIFTFILE.QR.D190106.T235144_V1";

	// public static final String[] EMD1 = new String[] {"AB","BC","CD","AE"};;
	// boolean contains = Arrays.stream(values).anyMatch("s"::equals);

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${batch-input-dir}")
	private String batchInputDir;

	@Autowired
	private PlatformTransactionManager transactionManager;

	
	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		return taskExecutor;
	}

	@Bean
	public Job importAmadeusJob(JobCompletionNotificationListener listener, Step importAmadeusData) {
		log.info("Entering Batch Config");
		System.out.println("Entering JOB+++++++++++++++>");
		return jobBuilderFactory.get("importAmadeusJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importAmadeusData).end().build();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importAmadeusData() {
		return stepBuilderFactory.get("AmadeusEtlRecord").<AmadeusEtlRecord, AmadeusEtlRecord>chunk(100)
				.reader(amadeusItemReader(null))
				.processor((ItemProcessor<? super AmadeusEtlRecord, ? extends AmadeusEtlRecord>) amadeusProcessor(
						amadeusRecordStagingProcessor()))
				.writer((ItemWriter<? super AmadeusEtlRecord>) amadeusWriter(null))
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusEtlRecord> amadeusItemReader(
			@Value("#{jobParameters[inboundFileName]}") String fileName) {

		FlatFileItemReader<AmadeusEtlRecord> reader = new FlatFileItemReader<AmadeusEtlRecord>();
		reader.setResource(new FileSystemResource(batchInputDir + "/" + fileName));
		reader.setLinesToSkip(1);
		// String processName = "";

		if (fileName.contains(ETL_LIFT)) {
			System.out.println("===================>>>>>>>>1");
			reader.setLineMapper(amadeusEtlLineMapper());
		} else if (fileName.contains(EMD_LIFT)) {
			System.out.println("===================>>>>>>>>2");
			reader.setLineMapper(amadeusEmdLineMapper());
		}
		// reader.setLineMapper(amadeusEtlLineMapper());

		return reader;
	}

	// @Bean(name = "amadeusEtlLineMapper")
	public LineMapper<AmadeusEtlRecord> amadeusEtlLineMapper() {
		// String fileName = "ETL_LIFT";

		// if (fileName.contains(ETL_LIFT)) {
		System.out.println("============1==========");
		PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("9*", (new AmadeusRecordStaging()).lineTokenizer());

		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());

		mapper.setFieldSetMappers(mappers);
		return mapper;
		/*
		 * } else { System.out.println("============2==========");
		 * PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new
		 * PatternMatchingCompositeLineMapper<>();
		 * 
		 * Map<String, LineTokenizer> tokenizers = new HashMap<String,
		 * LineTokenizer>(10); tokenizers.put("1*", (new
		 * AmadeusRecordStaging()).emdLineTokenizer()); tokenizers.put("2*", (new
		 * AmadeusRecordStaging()).emdLineTokenizer()); tokenizers.put("9*", (new
		 * AmadeusRecordStaging()).emdLineTokenizer());
		 * 
		 * mapper.setTokenizers(tokenizers);
		 * 
		 * Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String,
		 * FieldSetMapper<AmadeusEtlRecord>>(); mappers.put("1*", (new
		 * AmadeusRecordStaging()).fieldSetMapper()); mappers.put("2*", (new
		 * AmadeusRecordStaging()).fieldSetMapper()); mappers.put("9*", (new
		 * AmadeusRecordStaging()).fieldSetMapper());
		 * 
		 * mapper.setFieldSetMappers(mappers); return mapper; }
		 */
	}

//	@Qualifier()
	// @Bean(name = "amadeusEmdLineMapper")
	public LineMapper<AmadeusEtlRecord> amadeusEmdLineMapper() {

		System.out.println("============2==========");
		PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new AmadeusRecordStaging()).emdLineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).emdLineTokenizer());
		tokenizers.put("9*", (new AmadeusRecordStaging()).emdLineTokenizer());

		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());

		mapper.setFieldSetMappers(mappers);
		return mapper;
	}

	@Bean
	@StepScope
//	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter(File[] file) {
	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter(@Value("#{jobParameters[inboundFileName]}") String fileName) {

		System.out.println("File-------------->" + fileName);
		// System.out.println("File-------------->"+fileName);

		/*
		 * if(Arrays.stream(file).anyMatch("QR.AL.EML.D160119.T2001.PRD"::equals) ) {
		 * System.out.println("File NAme For EMD"+file); return new
		 * AmadeusRecordStaging().amadeusEmdwriter(); } else if
		 * (Arrays.stream(file).anyMatch("PRD_ETS_LIFTFILE.QR.D190106.T235144_V1"::
		 * equals) ) { System.out.println("File NAme For ETL"+file); return new
		 * AmadeusRecordStaging().amadeusEtlwriter(); }
		 */

		if (fileName.equals(EMD)) {
			System.out.println("File NAme For EMD" + fileName);
			return new AmadeusRecordStaging().amadeusEmdwriter();
		} else if (fileName.equals(ETL)) {
			System.out.println("File NAme For ETL" + fileName);
			return new AmadeusRecordStaging().amadeusEtlwriter();
		}

		return null;
	}

	/*
	 * @Bean public ItemWriter<? super AmadeusEtlRecord>
	 * amadeusRecordStagingEmdWriter() { return new AmadeusRecordStaging().writer();
	 * }
	 */
	@SuppressWarnings("serial")
	@Bean
	@StepScope
	public ClassifierCompositeItemWriter<? extends AmadeusEtlRecord> amadeusWriter(
			ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter

	) {
		ClassifierCompositeItemWriter<AmadeusEtlRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemWriter<? super AmadeusEtlRecord>>() {

					@Override
					public ItemWriter<? super AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordStaging) {

//							return amadeusRecordStagingWriter(new File("batchInputDir").listFiles());
							return amadeusRecordStagingWriter;
						}

						return null;
					}

				});
		return classifierCompositeItemWriter;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor() {
		return new AmadeusRecordStaging().processor();
	}

	@SuppressWarnings("serial")
	@Bean
	@StepScope
	public ClassifierCompositeItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusProcessor(
			ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor

	) {
		ClassifierCompositeItemProcessor<AmadeusEtlRecord, AmadeusEtlRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemProcessor<?, ? extends AmadeusEtlRecord>>() {

					@Override
					public ItemProcessor<?, ? extends AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordStaging) {
							return amadeusRecordStagingProcessor;

						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}

}
