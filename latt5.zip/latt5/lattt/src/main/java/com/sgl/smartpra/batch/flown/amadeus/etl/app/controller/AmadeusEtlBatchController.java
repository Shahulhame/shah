package com.sgl.smartpra.batch.flown.amadeus.etl.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.config.FeignConfiguration.BatchGlobalFeignClient;
import com.sgl.smartpra.batch.global.model.InboundFileLog;

@RestController
public class AmadeusEtlBatchController {
	
	private static final Logger log = LoggerFactory.getLogger(AmadeusEtlBatchController.class);

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	Job importAmadeusJob;

	@Autowired
	BatchGlobalFeignClient batchGlobalFeignClient;

	@RequestMapping("/etl/invokejob")
	public String handle(@RequestParam("inboundFileName") String inboundFileName) throws Exception {
		log.info("Emtering Amadeus Etl Controller");

		InboundFileLog inboundFileLog = new InboundFileLog();
		inboundFileLog.setInboundFileName(inboundFileName);
		inboundFileLog.setFileRecordCount(1);
		inboundFileLog.setFileType("amadeus");

		inboundFileLog = batchGlobalFeignClient.createInboundFileLog(inboundFileLog);

		JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
				.addString("inboundFileName", inboundFileLog.getInboundFileName().toString())
				.addLong("fileId", inboundFileLog.getInboundFileId().longValue()).toJobParameters();
		jobLauncher.run(importAmadeusJob, jobParameters);

		return "Batch job has been invoked";
	}
}
