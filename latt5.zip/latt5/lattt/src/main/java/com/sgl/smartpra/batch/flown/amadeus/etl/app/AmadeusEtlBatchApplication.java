package com.sgl.smartpra.batch.flown.amadeus.etl.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableBatchProcessing
@EnableScheduling
@EnableDiscoveryClient
@EnableCircuitBreaker
@EnableSwagger2
@EnableFeignClients
public class AmadeusEtlBatchApplication {

	private static final Logger log = LoggerFactory.getLogger(AmadeusEtlBatchApplication.class);

	public static void main(String[] args) throws Exception {
		log.info("Emtering Amadeus Etl Application");
		SpringApplication.run(AmadeusEtlBatchApplication.class, args);
	}

}