package com.sgl.smartpra.batch.flown.amadeus.etl.app.config;

import org.springframework.batch.item.file.FlatFileItemReader;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;

public class AmadeusFlatFileItemReader extends FlatFileItemReader<AmadeusEtlRecord>{

	
	public AmadeusFlatFileItemReader() {
		super();
		
	}

}
