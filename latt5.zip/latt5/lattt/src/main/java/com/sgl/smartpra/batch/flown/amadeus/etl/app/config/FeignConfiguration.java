package com.sgl.smartpra.batch.flown.amadeus.etl.app.config;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sgl.smartpra.batch.global.model.InboundFileLog;

@Configuration
public class FeignConfiguration {

	@FeignClient(value = "smartpra-batch-global-app", path = "/batch-global")
	public interface BatchGlobalFeignClient {

		@PostMapping("/inboundFileLogs")
		public InboundFileLog createInboundFileLog(@Valid @RequestBody InboundFileLog inboundFileLog);

	}

}
