package com.sgl.smartpra.batch.flown.amadeus.etl.app.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;

@SuppressWarnings("serial")
@Component
public class AmadeusRecordStagingProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordStaging, AmadeusRecordStaging> {

	@Override
	public AmadeusRecordStaging process(AmadeusRecordStaging amadeusRecordStaging) throws Exception {
		super.process(amadeusRecordStaging);
		return amadeusRecordStaging;
	}
}
