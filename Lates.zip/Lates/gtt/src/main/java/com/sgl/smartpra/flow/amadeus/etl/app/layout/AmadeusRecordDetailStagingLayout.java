package com.sgl.smartpra.flow.amadeus.etl.app.layout;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;
import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AmadeusRecordDetailStagingLayout extends FixedLengthRecordLayout {

	@SuppressWarnings("rawtypes")
	public AmadeusRecordDetailStagingLayout() {

		int DATA_START_POS = 252;

		Map<String, Integer> list = new LinkedHashMap<>();

		list.put("saleCouponNumber", 1);
		list.put("origin", 4);
		list.put("destination", 4);
		list.put("airlineCode", 3);
		list.put("saleFlightNumber", 4);
		list.put("saleLocalFlightDate", 5);
		list.put("sellingClass", 1);
		list.put("fareBasis", 4);
		list.put("reservationStatus", 1);
		list.put("freeBaggageAllowance", 2);
		list.put("involuntaryIndicator", 1);
		list.put("stopOverCode", 1);
		list.put("notValidBeforeDate", 5);
		list.put("notValidAfterDate", 5);

		fixedLengthFieldLayoutList = new ArrayList<FixedLengthFieldLayout>();
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("issAirline", 2, 4));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("documentNumber", 5, 14));
		fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout("couponNumber", 16, 16));
		int start = DATA_START_POS;
		for (int i = 0; i < 16; i++) {
			for (Entry enrty : list.entrySet()) {
				String col = enrty.getKey() + "-" + i;
				Integer size = (Integer) enrty.getValue();
				fixedLengthFieldLayoutList.add(new FixedLengthFieldLayout(col, start, start + 1));
System.out.println("Columns++++++++++++++"+enrty.getKey());
System.out.println("Columns++++++++++++++"+enrty.getValue());
			}
		}

	}
}
