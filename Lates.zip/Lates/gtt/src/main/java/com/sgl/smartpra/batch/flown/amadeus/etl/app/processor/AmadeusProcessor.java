package com.sgl.smartpra.batch.flown.amadeus.etl.app.processor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusEtlRecord;
@Component
@Scope(value = "Prototype")
public class AmadeusProcessor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Value("#{jobParameters['inboundFileId']}")
	public Integer inboundFileId;

	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public void process(AmadeusEtlRecord amadeusEtlRecord) {

		amadeusEtlRecord.setCreatedBy("Amadeus");
		amadeusEtlRecord.setCreatedDate(new Timestamp(new Date().getTime()));

	}
}
