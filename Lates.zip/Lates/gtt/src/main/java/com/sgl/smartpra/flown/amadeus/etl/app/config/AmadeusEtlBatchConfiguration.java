package com.sgl.smartpra.flown.amadeus.etl.app.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.FooterDetails;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.HeaderDetails;

@Configuration
@EnableBatchProcessing
public class AmadeusEtlBatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;
	
	@Value("${max-threads}")
	private int maxThreads;

	@Autowired
     private PlatformTransactionManager transactionManager;
	 
	 @Bean
	 public TaskExecutor taskExecutor() {
	 	SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
	 	taskExecutor.setConcurrencyLimit(maxThreads);
	 	return taskExecutor;
	 }

	@Bean
	public Job importYQYRJob(com.sgl.smartpra.flow.amadeus.etl.app.listener.JobCompletionNotificationListener listener, Step importData) {

		 return jobBuilderFactory
				.get("importAmadeusJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(importData)
				.end()
				.build();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importData() {
		return stepBuilderFactory.get("AmadeusEtlRecord").<AmadeusEtlRecord, AmadeusEtlRecord>chunk(100)
				.reader(amadeusItemReader(null))
				.processor((ItemProcessor<? super AmadeusEtlRecord, ? extends AmadeusEtlRecord>) amadeusProcessor(amadeusRecordStagingProcessor()
						,amadeusRecordDetailStagingProcessor()
						))
				.writer((ItemWriter<? super AmadeusEtlRecord>)amadeusWriter(amadeusRecordStagingWriter()
						,amadeusRecordDetailStagingWriter()
						))
				.transactionManager(transactionManager)
				.taskExecutor(taskExecutor())
				.throttleLimit(maxThreads)
				.build();
	}
	

	

	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusEtlRecord> amadeusItemReader(@Value("#{jobParameters[inboundFileName]}") String resource) {

		FlatFileItemReader<AmadeusEtlRecord> reader = new FlatFileItemReader<AmadeusEtlRecord>();
		reader.setResource(new ClassPathResource("data/"+resource));
		reader.setLineMapper(amadeusLineMapper());
		return reader;
	}

	@Bean
	public LineMapper<AmadeusEtlRecord> amadeusLineMapper() {
		PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("9*", (new FooterDetails()).lineTokenizer());
		
		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*",(new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new FooterDetails()).fieldSetMapper());
	

		return mapper;
	}
	
	@Bean
	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter() {
		return new AmadeusRecordStaging().writer();
	}

	@Bean
	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordDetailStagingWriter() {
		return new AmadeusRecordDetailStaging().writer();
	}

	
	

	@SuppressWarnings("serial")
	@Bean
	public ClassifierCompositeItemWriter<? extends AmadeusEtlRecord> amadeusWriter(
			ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter,
			ItemWriter<? super AmadeusEtlRecord>  amadeusRecordDetailStagingWriter
			
			) {
		ClassifierCompositeItemWriter<AmadeusEtlRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter.setClassifier(new Classifier<AmadeusEtlRecord, ItemWriter<? super AmadeusEtlRecord>>() {
		
			@Override
			public ItemWriter<? super AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
				if (classifiable instanceof AmadeusRecordStaging) {
					return amadeusRecordStagingWriter();
				} else if (classifiable instanceof AmadeusRecordDetailStaging) {
					return amadeusRecordDetailStagingWriter;
				}

				return null;
			}

		});
		return classifierCompositeItemWriter;
	}
	
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor(){
		return new AmadeusRecordDetailStaging().processor();
	}
	
	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordDetailStagingProcessor(){
		return new AmadeusRecordDetailStaging().processor();
	}

	

	@Bean
	  @StepScope
	public ClassifierCompositeItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusProcessor(
			ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor,
			ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordDetailStagingProcessor
			
			
			) {
		ClassifierCompositeItemProcessor<AmadeusEtlRecord, AmadeusEtlRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemProcessor<?, ? extends AmadeusEtlRecord>>() {
					
					@Override
					public ItemProcessor<?, ? extends AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordStaging) {
							return amadeusRecordStagingProcessor;
						
						}else if (classifiable instanceof AmadeusRecordDetailStaging) {
							return amadeusRecordDetailStagingProcessor;
						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}
	
	
	
	
	
	
	
	
	
}

