package com.sgl.smartpra.flow.amadeus.etl.app.layout;

import com.sgl.smartpra.batch.global.model.FixedLengthRecordLayout;

public class AmadeusOldTaxStagingLayout extends FixedLengthRecordLayout{

    public AmadeusOldTaxStagingLayout(){
    	
    	
       
    }
}
