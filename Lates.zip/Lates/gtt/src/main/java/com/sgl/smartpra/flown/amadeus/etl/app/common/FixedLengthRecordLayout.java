package com.sgl.smartpra.flown.amadeus.etl.app.common;

import java.util.List;

import org.springframework.batch.item.file.transform.Range;

import com.sgl.smartpra.batch.global.model.FixedLengthFieldLayout;

public class FixedLengthRecordLayout {

	protected static List<FixedLengthFieldLayout> recordFixedLengthFieldLayoutList;

	public Range[] getColumns() {

		Range[] rangeArray = new Range[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldLayout : fixedLengthFieldLayoutList)
			if (fixedLengthFieldLayout.getEndPosition() == null) {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition());
			} else {
				rangeArray[index] = new Range(fixedLengthFieldLayout.getStartPosition(),
						fixedLengthFieldLayout.getEndPosition());
				index++;
			}
		return rangeArray;
	}

	public String[] getNames() {

		String[] columNameArray = new String[fixedLengthFieldLayoutList.size()];
		int index = 0;
		for (FixedLengthFieldLayout fixedLengthFieldNameLayout : fixedLengthFieldLayoutList) {
			columNameArray[index] = fixedLengthFieldNameLayout.getFieldname();
			index++;
		}

		return columNameArray;

	}

	public static List<FixedLengthFieldLayout> getFixedLengthFieldLayoutList() {
		return fixedLengthFieldLayoutList;
	}
}
