package com.sgl.smartpra.batch.flown.amadeus.etl.app.processor;

import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.github.andrewoma.dexx.collection.ArrayList;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecord;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordDetail;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.flow.amadeus.etl.app.domain.AmadeusRecordStaging;

@SuppressWarnings("serial")
@Component
@Scope(value = "step")
public class AmadeusRecordDetailStagingProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordDetailStaging, AmadeusRecordDetailStaging> {

	@Override
	public AmadeusRecordDetailStaging process(AmadeusRecordDetailStaging amadeusRecordDetailStaging) throws Exception {
		super.process(amadeusRecordDetailStaging);
		

		AmadeusRecordStaging    amadeusRecordStaging=new  AmadeusRecordStaging();
		List<AmadeusRecordDetailStaging> amadeusRecordDetailStaging1=(List<AmadeusRecordDetailStaging>) new ArrayList<AmadeusRecordDetailStaging>();
		AmadeusRecord amadeusRecord=new AmadeusRecord();
		amadeusRecord.setIssAirline(amadeusRecordStaging.getIssAirline());
		amadeusRecord.setDocumentNumber(amadeusRecordStaging.getDocumentNumber());
		amadeusRecord.setCouponNumber(amadeusRecordStaging.getCouponNumber());
		
		for(int i=0;i<16;i++) {
			AmadeusRecordDetail amadeusRecordDetail=new AmadeusRecordDetail();	
			amadeusRecordDetail.setAirlineCode(amadeusRecordDetailStaging.getAirlineCode());
			amadeusRecordDetail.setOrigin(amadeusRecordDetailStaging.getOrigin());
			amadeusRecordDetail.setDestination(amadeusRecordDetailStaging.getDestination());
			amadeusRecordDetail.setSaleFlightNumber(amadeusRecordDetailStaging.getSaleFlightNumber());
			amadeusRecordDetailStaging1.add(amadeusRecordDetailStaging);
			
		}
		
		return amadeusRecordDetailStaging;
	}
}
