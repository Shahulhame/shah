package com.sgl.smartpra.flow.amadeus.etl.app.domain;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

import java.sql.Timestamp;

/**
 * The persistent class for the amadeus_record_exch_detail_stg database table.
 * 
 */
@Entity
@Table(name = "amadeus_record_exch_detail_stg")
@NamedQuery(name = "AmadeusRecordExchDetailStg.findAll", query = "SELECT a FROM AmadeusRecordExchDetailStg a")
public class AmadeusRecordExchDetailStaging extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "amds_rec_exc_load_id")
	private int amdsRecExcLoadId;

	@Column(name = "coupon_number")
	private String couponNumber;

	@Column(name = "disruption_ind")
	private String disruptionInd;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "iss_airline")
	private String issAirline;

	@Column(name = "marketing_carrier_code")
	private String marketingCarrierCode;

	@Column(name = "old_coupon_number")
	private String oldCouponNumber;

	@Column(name = "old_dest_airport_code")
	private String oldDestAirportCode;

	@Column(name = "old_document_number")
	private String oldDocumentNumber;

	@Column(name = "old_flight_date")
	private String oldFlightDate;

	@Column(name = "old_flight_dept_time")
	private String oldFlightDeptTime;

	@Column(name = "old_flight_no")
	private String oldFlightNo;

	@Column(name = "old_iss_airline")
	private String oldIssAirline;

	@Column(name = "old_orig_airport_code")
	private String oldOrigAirportCode;

	@Column(name = "old_rbd")
	private String oldRbd;

	@Column(name = "stop_over_code")
	private String stopOverCode;

	@Column(name = "usage_document_number")
	private String usageDocumentNumber;

	// bi-directional many-to-one association to AmadeusRecordStg
	@ManyToOne
	@JoinColumn(name = "amadeus_load_id")
	private AmadeusRecordStaging amadeusRecordStg;

	public AmadeusRecordExchDetailStaging() {
	}

	public int getAmdsRecExcLoadId() {
		return this.amdsRecExcLoadId;
	}

	public void setAmdsRecExcLoadId(int amdsRecExcLoadId) {
		this.amdsRecExcLoadId = amdsRecExcLoadId;
	}

	public String getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getDisruptionInd() {
		return this.disruptionInd;
	}

	public void setDisruptionInd(String disruptionInd) {
		this.disruptionInd = disruptionInd;
	}

	public String getDocumentNumber() {
		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getIssAirline() {
		return this.issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getMarketingCarrierCode() {
		return this.marketingCarrierCode;
	}

	public void setMarketingCarrierCode(String marketingCarrierCode) {
		this.marketingCarrierCode = marketingCarrierCode;
	}

	public String getOldCouponNumber() {
		return this.oldCouponNumber;
	}

	public void setOldCouponNumber(String oldCouponNumber) {
		this.oldCouponNumber = oldCouponNumber;
	}

	public String getOldDestAirportCode() {
		return this.oldDestAirportCode;
	}

	public void setOldDestAirportCode(String oldDestAirportCode) {
		this.oldDestAirportCode = oldDestAirportCode;
	}

	public String getOldDocumentNumber() {
		return this.oldDocumentNumber;
	}

	public void setOldDocumentNumber(String oldDocumentNumber) {
		this.oldDocumentNumber = oldDocumentNumber;
	}

	public String getOldFlightDate() {
		return this.oldFlightDate;
	}

	public void setOldFlightDate(String oldFlightDate) {
		this.oldFlightDate = oldFlightDate;
	}

	public String getOldFlightDeptTime() {
		return this.oldFlightDeptTime;
	}

	public void setOldFlightDeptTime(String oldFlightDeptTime) {
		this.oldFlightDeptTime = oldFlightDeptTime;
	}

	public String getOldFlightNo() {
		return this.oldFlightNo;
	}

	public void setOldFlightNo(String oldFlightNo) {
		this.oldFlightNo = oldFlightNo;
	}

	public String getOldIssAirline() {
		return this.oldIssAirline;
	}

	public void setOldIssAirline(String oldIssAirline) {
		this.oldIssAirline = oldIssAirline;
	}

	public String getOldOrigAirportCode() {
		return this.oldOrigAirportCode;
	}

	public void setOldOrigAirportCode(String oldOrigAirportCode) {
		this.oldOrigAirportCode = oldOrigAirportCode;
	}

	public String getOldRbd() {
		return this.oldRbd;
	}

	public void setOldRbd(String oldRbd) {
		this.oldRbd = oldRbd;
	}

	public String getStopOverCode() {
		return this.stopOverCode;
	}

	public void setStopOverCode(String stopOverCode) {
		this.stopOverCode = stopOverCode;
	}

	public String getUsageDocumentNumber() {
		return this.usageDocumentNumber;
	}

	public void setUsageDocumentNumber(String usageDocumentNumber) {
		this.usageDocumentNumber = usageDocumentNumber;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return this.amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

}