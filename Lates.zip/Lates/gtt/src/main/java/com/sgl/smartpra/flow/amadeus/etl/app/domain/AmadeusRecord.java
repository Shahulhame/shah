package com.sgl.smartpra.flow.amadeus.etl.app.domain;

import java.io.Serializable;
import java.util.List;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * The persistent class for the amadeus_record_stg database table.
 * 
 */

public class AmadeusRecord extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private int amadeusLoadId;

	private String additionalCollectionTotal;

	private String additionalInformation;

	private String agencyNumber;

	private String airlineChangePerformer;

	private String airlineCodeEmd;

	private String amountEnteredByAgent;

	private String approvedCollectionCode;

	private String approvedCollectionCode2;

	private String approvedCollectionCode3;

	private String associationStatus;

	private String bankersExchangeRate;

	private String bookingReference;

	private String checkDigit;

	private String commissionAmount;

	private String commissionRate;

	private String couponNumber;

	private String couponRevenueIndicator;

	private String couponSlsIndicator;

	private String couponValue;

	private String currOfAmtEnteredByAgent;

	private String currencyOfAddlCollection;

	private String currencyOfCommissionAmount;

	private String currencyOfNetFare;

	private String currencyOfReportedFare;

	private String currencyOfTransTotalAmt;

	private String documentNumber;

	private String documentType;

	private String ebdChargeCurrency;

	private String ebdChargeQualifier;

	private String ebdRatePerUnit;

	private String ebdTotalNoOfUnits;

	private String ebdUnitQualifier;

	private String emdDocumentAmount;

	private String emdDocumentAmountCurrency;

	private String endorsementRestrictionText;

	private String equivalentFare;

	private String fareBasis;

	private String fareCalcModeIndicator;

	private String fareConstruction;

	private int fileId;

	private String fileSource;

	private String flightNumber;

	private String formOfIdentVendorCode;

	private String formOfIdentificationNumber;

	private String formOfIdentificationType;

	private String formOfPayment;

	private String formOfPayment2;

	private String formOfPayment3;

	private String frequentFlyerAirlineCode;

	private String frequentFlyerCustomerCode;

	private String inConnectionCouponNo;

	private String inConnectionDocNo;

	private String internationalDomesticInd;

	private String internationalSaleIndicaor;

	private String issAirline;

	private String issueDate;

	private String issuingOfficeLocation;

	private String localDepartureDate;

	private String manualIndicator;

	private String netFare;

	private String netRemitIndicator;

	private String netReportingIndicator;

	
	private String nonEndorsableIndicator;

	
	private String nonExchangeableAmount;

	
	private String nonExchangeableAmtCurr;

	
	private String nonRefundableAmount;

	
	private String nonRefundableAmountCurr;

	
	private String nonRefundableIndicator;

	
	private String notValidAfterDate;

	
	private String notValidBeforeDate;

	private String oldApprovedCollectionCode1;

	private String oldApprovedCollectionCode2;

	private String oldApprovedCollectionCode3;

	private String oldFormOfPayment;

	private String oldFormOfPayment2;

	private String oldFormOfPayment3;

	private String originalEmdDocNumber1;

	private String originalEmdDocNumber2;

	private String originalEmdDocNumber3;

	private String originalEmdDocNumber4;

	private String originalEmdDocNumber5;

	private String originalEmdDocNumber6;

	private String originalEmdDocNumber7;

	private String originalIssueInformation;

	private String passengerName;

	private String paymentCurrency;

	private String penaltyRestrictionIndicator;

	private String presentCreditCardIndicator;

	private String reasonForIssuanceCode;

	private String reasonForIssuanceSubCode;

	private String recordType;

	private String reportedFare;

	private String revenueAttributionNumber;

	private String settlementAuthorizationCode;

	private String settlementAuthorizationEmd;

	private String soldDestinationCode;

	private String soldLocalDepartDate;

	private String soldMarketingCarrier;

	private String soldMarketingFlightNo;

	private String soldOperatingCarrier;

	private String soldOperatingFlightNo;

	private String soldOriginCode;

	private String staffResEntitlement;

	private String status;

	private String ticketingModeIndicator;

	private String tourCode;

	private String transactionTotalAmount;

	private String usageAirline;

	private String usageDestinationCode;

	private String usageDestinationCodeEmd;

	private String usageDocNumber;

	private String usageEmdDate;

	private String usageLocalFlightDate;

	private String usageMarketingCarrierCode;

	private String usageOperatingCarrier;

	private String usageOperatingFlightNumber;

	private String usageOperatingFlightSuffix;

	private String usageOriginCode;

	private String usageOriginCodeEmd;

	private String usagePerformer;

	private String usageType;

	private String usageUtcFlightDate;

	private String usedCabinClass;

	
	private List<AmadeusOldTaxStaging> amadeusOldTaxStgs;

	
	
	private List<AmadeusRecordDetailStaging> amadeusRecordDetailStgs;

	
	private List<AmadeusRecordExchDetailStaging> amadeusRecordExchDetailStgs;

	
	

	
	

	



	public int getAmadeusLoadId() {
		return amadeusLoadId;
	}

	public void setAmadeusLoadId(int amadeusLoadId) {
		this.amadeusLoadId = amadeusLoadId;
	}

	public String getAdditionalCollectionTotal() {
		return additionalCollectionTotal;
	}

	public void setAdditionalCollectionTotal(String additionalCollectionTotal) {
		this.additionalCollectionTotal = additionalCollectionTotal;
	}

	public String getAdditionalInformation() {
		return additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getAgencyNumber() {
		return agencyNumber;
	}

	public void setAgencyNumber(String agencyNumber) {
		this.agencyNumber = agencyNumber;
	}

	public String getAirlineChangePerformer() {
		return airlineChangePerformer;
	}

	public void setAirlineChangePerformer(String airlineChangePerformer) {
		this.airlineChangePerformer = airlineChangePerformer;
	}

	public String getAirlineCodeEmd() {
		return airlineCodeEmd;
	}

	public void setAirlineCodeEmd(String airlineCodeEmd) {
		this.airlineCodeEmd = airlineCodeEmd;
	}

	public String getAmountEnteredByAgent() {
		return amountEnteredByAgent;
	}

	public void setAmountEnteredByAgent(String amountEnteredByAgent) {
		this.amountEnteredByAgent = amountEnteredByAgent;
	}

	public String getApprovedCollectionCode() {
		return approvedCollectionCode;
	}

	public void setApprovedCollectionCode(String approvedCollectionCode) {
		this.approvedCollectionCode = approvedCollectionCode;
	}

	public String getApprovedCollectionCode2() {
		return approvedCollectionCode2;
	}

	public void setApprovedCollectionCode2(String approvedCollectionCode2) {
		this.approvedCollectionCode2 = approvedCollectionCode2;
	}

	public String getApprovedCollectionCode3() {
		return approvedCollectionCode3;
	}

	public void setApprovedCollectionCode3(String approvedCollectionCode3) {
		this.approvedCollectionCode3 = approvedCollectionCode3;
	}

	public String getAssociationStatus() {
		return associationStatus;
	}

	public void setAssociationStatus(String associationStatus) {
		this.associationStatus = associationStatus;
	}

	public String getBankersExchangeRate() {
		return bankersExchangeRate;
	}

	public void setBankersExchangeRate(String bankersExchangeRate) {
		this.bankersExchangeRate = bankersExchangeRate;
	}

	public String getBookingReference() {
		return bookingReference;
	}

	public void setBookingReference(String bookingReference) {
		this.bookingReference = bookingReference;
	}

	public String getCheckDigit() {
		return checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCommissionAmount() {
		return commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(String commissionRate) {
		this.commissionRate = commissionRate;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponRevenueIndicator() {
		return couponRevenueIndicator;
	}

	public void setCouponRevenueIndicator(String couponRevenueIndicator) {
		this.couponRevenueIndicator = couponRevenueIndicator;
	}

	public String getCouponSlsIndicator() {
		return couponSlsIndicator;
	}

	public void setCouponSlsIndicator(String couponSlsIndicator) {
		this.couponSlsIndicator = couponSlsIndicator;
	}

	public String getCouponValue() {
		return couponValue;
	}

	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}

	public String getCurrOfAmtEnteredByAgent() {
		return currOfAmtEnteredByAgent;
	}

	public void setCurrOfAmtEnteredByAgent(String currOfAmtEnteredByAgent) {
		this.currOfAmtEnteredByAgent = currOfAmtEnteredByAgent;
	}

	public String getCurrencyOfAddlCollection() {
		return currencyOfAddlCollection;
	}

	public void setCurrencyOfAddlCollection(String currencyOfAddlCollection) {
		this.currencyOfAddlCollection = currencyOfAddlCollection;
	}

	public String getCurrencyOfCommissionAmount() {
		return currencyOfCommissionAmount;
	}

	public void setCurrencyOfCommissionAmount(String currencyOfCommissionAmount) {
		this.currencyOfCommissionAmount = currencyOfCommissionAmount;
	}

	public String getCurrencyOfNetFare() {
		return currencyOfNetFare;
	}

	public void setCurrencyOfNetFare(String currencyOfNetFare) {
		this.currencyOfNetFare = currencyOfNetFare;
	}

	public String getCurrencyOfReportedFare() {
		return currencyOfReportedFare;
	}

	public void setCurrencyOfReportedFare(String currencyOfReportedFare) {
		this.currencyOfReportedFare = currencyOfReportedFare;
	}

	public String getCurrencyOfTransTotalAmt() {
		return currencyOfTransTotalAmt;
	}

	public void setCurrencyOfTransTotalAmt(String currencyOfTransTotalAmt) {
		this.currencyOfTransTotalAmt = currencyOfTransTotalAmt;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEbdChargeCurrency() {
		return ebdChargeCurrency;
	}

	public void setEbdChargeCurrency(String ebdChargeCurrency) {
		this.ebdChargeCurrency = ebdChargeCurrency;
	}

	public String getEbdChargeQualifier() {
		return ebdChargeQualifier;
	}

	public void setEbdChargeQualifier(String ebdChargeQualifier) {
		this.ebdChargeQualifier = ebdChargeQualifier;
	}

	public String getEbdRatePerUnit() {
		return ebdRatePerUnit;
	}

	public void setEbdRatePerUnit(String ebdRatePerUnit) {
		this.ebdRatePerUnit = ebdRatePerUnit;
	}

	public String getEbdTotalNoOfUnits() {
		return ebdTotalNoOfUnits;
	}

	public void setEbdTotalNoOfUnits(String ebdTotalNoOfUnits) {
		this.ebdTotalNoOfUnits = ebdTotalNoOfUnits;
	}

	public String getEbdUnitQualifier() {
		return ebdUnitQualifier;
	}

	public void setEbdUnitQualifier(String ebdUnitQualifier) {
		this.ebdUnitQualifier = ebdUnitQualifier;
	}

	public String getEmdDocumentAmount() {
		return emdDocumentAmount;
	}

	public void setEmdDocumentAmount(String emdDocumentAmount) {
		this.emdDocumentAmount = emdDocumentAmount;
	}

	public String getEmdDocumentAmountCurrency() {
		return emdDocumentAmountCurrency;
	}

	public void setEmdDocumentAmountCurrency(String emdDocumentAmountCurrency) {
		this.emdDocumentAmountCurrency = emdDocumentAmountCurrency;
	}

	public String getEndorsementRestrictionText() {
		return endorsementRestrictionText;
	}

	public void setEndorsementRestrictionText(String endorsementRestrictionText) {
		this.endorsementRestrictionText = endorsementRestrictionText;
	}

	public String getEquivalentFare() {
		return equivalentFare;
	}

	public void setEquivalentFare(String equivalentFare) {
		this.equivalentFare = equivalentFare;
	}

	public String getFareBasis() {
		return fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getFareCalcModeIndicator() {
		return fareCalcModeIndicator;
	}

	public void setFareCalcModeIndicator(String fareCalcModeIndicator) {
		this.fareCalcModeIndicator = fareCalcModeIndicator;
	}

	public String getFareConstruction() {
		return fareConstruction;
	}

	public void setFareConstruction(String fareConstruction) {
		this.fareConstruction = fareConstruction;
	}

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getFileSource() {
		return fileSource;
	}

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFormOfIdentVendorCode() {
		return formOfIdentVendorCode;
	}

	public void setFormOfIdentVendorCode(String formOfIdentVendorCode) {
		this.formOfIdentVendorCode = formOfIdentVendorCode;
	}

	public String getFormOfIdentificationNumber() {
		return formOfIdentificationNumber;
	}

	public void setFormOfIdentificationNumber(String formOfIdentificationNumber) {
		this.formOfIdentificationNumber = formOfIdentificationNumber;
	}

	public String getFormOfIdentificationType() {
		return formOfIdentificationType;
	}

	public void setFormOfIdentificationType(String formOfIdentificationType) {
		this.formOfIdentificationType = formOfIdentificationType;
	}

	public String getFormOfPayment() {
		return formOfPayment;
	}

	public void setFormOfPayment(String formOfPayment) {
		this.formOfPayment = formOfPayment;
	}

	public String getFormOfPayment2() {
		return formOfPayment2;
	}

	public void setFormOfPayment2(String formOfPayment2) {
		this.formOfPayment2 = formOfPayment2;
	}

	public String getFormOfPayment3() {
		return formOfPayment3;
	}

	public void setFormOfPayment3(String formOfPayment3) {
		this.formOfPayment3 = formOfPayment3;
	}

	public String getFrequentFlyerAirlineCode() {
		return frequentFlyerAirlineCode;
	}

	public void setFrequentFlyerAirlineCode(String frequentFlyerAirlineCode) {
		this.frequentFlyerAirlineCode = frequentFlyerAirlineCode;
	}

	public String getFrequentFlyerCustomerCode() {
		return frequentFlyerCustomerCode;
	}

	public void setFrequentFlyerCustomerCode(String frequentFlyerCustomerCode) {
		this.frequentFlyerCustomerCode = frequentFlyerCustomerCode;
	}

	public String getInConnectionCouponNo() {
		return inConnectionCouponNo;
	}

	public void setInConnectionCouponNo(String inConnectionCouponNo) {
		this.inConnectionCouponNo = inConnectionCouponNo;
	}

	public String getInConnectionDocNo() {
		return inConnectionDocNo;
	}

	public void setInConnectionDocNo(String inConnectionDocNo) {
		this.inConnectionDocNo = inConnectionDocNo;
	}

	public String getInternationalDomesticInd() {
		return internationalDomesticInd;
	}

	public void setInternationalDomesticInd(String internationalDomesticInd) {
		this.internationalDomesticInd = internationalDomesticInd;
	}

	public String getInternationalSaleIndicaor() {
		return internationalSaleIndicaor;
	}

	public void setInternationalSaleIndicaor(String internationalSaleIndicaor) {
		this.internationalSaleIndicaor = internationalSaleIndicaor;
	}

	public String getIssAirline() {
		return issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuingOfficeLocation() {
		return issuingOfficeLocation;
	}

	public void setIssuingOfficeLocation(String issuingOfficeLocation) {
		this.issuingOfficeLocation = issuingOfficeLocation;
	}

	public String getLocalDepartureDate() {
		return localDepartureDate;
	}

	public void setLocalDepartureDate(String localDepartureDate) {
		this.localDepartureDate = localDepartureDate;
	}

	public String getManualIndicator() {
		return manualIndicator;
	}

	public void setManualIndicator(String manualIndicator) {
		this.manualIndicator = manualIndicator;
	}

	public String getNetFare() {
		return netFare;
	}

	public void setNetFare(String netFare) {
		this.netFare = netFare;
	}

	public String getNetRemitIndicator() {
		return netRemitIndicator;
	}

	public void setNetRemitIndicator(String netRemitIndicator) {
		this.netRemitIndicator = netRemitIndicator;
	}

	public String getNetReportingIndicator() {
		return netReportingIndicator;
	}

	public void setNetReportingIndicator(String netReportingIndicator) {
		this.netReportingIndicator = netReportingIndicator;
	}

	public String getNonEndorsableIndicator() {
		return nonEndorsableIndicator;
	}

	public void setNonEndorsableIndicator(String nonEndorsableIndicator) {
		this.nonEndorsableIndicator = nonEndorsableIndicator;
	}

	public String getNonExchangeableAmount() {
		return nonExchangeableAmount;
	}

	public void setNonExchangeableAmount(String nonExchangeableAmount) {
		this.nonExchangeableAmount = nonExchangeableAmount;
	}

	public String getNonExchangeableAmtCurr() {
		return nonExchangeableAmtCurr;
	}

	public void setNonExchangeableAmtCurr(String nonExchangeableAmtCurr) {
		this.nonExchangeableAmtCurr = nonExchangeableAmtCurr;
	}

	public String getNonRefundableAmount() {
		return nonRefundableAmount;
	}

	public void setNonRefundableAmount(String nonRefundableAmount) {
		this.nonRefundableAmount = nonRefundableAmount;
	}

	public String getNonRefundableAmountCurr() {
		return nonRefundableAmountCurr;
	}

	public void setNonRefundableAmountCurr(String nonRefundableAmountCurr) {
		this.nonRefundableAmountCurr = nonRefundableAmountCurr;
	}

	public String getNonRefundableIndicator() {
		return nonRefundableIndicator;
	}

	public void setNonRefundableIndicator(String nonRefundableIndicator) {
		this.nonRefundableIndicator = nonRefundableIndicator;
	}

	public String getNotValidAfterDate() {
		return notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getNotValidBeforeDate() {
		return notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getOldApprovedCollectionCode1() {
		return oldApprovedCollectionCode1;
	}

	public void setOldApprovedCollectionCode1(String oldApprovedCollectionCode1) {
		this.oldApprovedCollectionCode1 = oldApprovedCollectionCode1;
	}

	public String getOldApprovedCollectionCode2() {
		return oldApprovedCollectionCode2;
	}

	public void setOldApprovedCollectionCode2(String oldApprovedCollectionCode2) {
		this.oldApprovedCollectionCode2 = oldApprovedCollectionCode2;
	}

	public String getOldApprovedCollectionCode3() {
		return oldApprovedCollectionCode3;
	}

	public void setOldApprovedCollectionCode3(String oldApprovedCollectionCode3) {
		this.oldApprovedCollectionCode3 = oldApprovedCollectionCode3;
	}

	public String getOldFormOfPayment() {
		return oldFormOfPayment;
	}

	public void setOldFormOfPayment(String oldFormOfPayment) {
		this.oldFormOfPayment = oldFormOfPayment;
	}

	public String getOldFormOfPayment2() {
		return oldFormOfPayment2;
	}

	public void setOldFormOfPayment2(String oldFormOfPayment2) {
		this.oldFormOfPayment2 = oldFormOfPayment2;
	}

	public String getOldFormOfPayment3() {
		return oldFormOfPayment3;
	}

	public void setOldFormOfPayment3(String oldFormOfPayment3) {
		this.oldFormOfPayment3 = oldFormOfPayment3;
	}

	public String getOriginalEmdDocNumber1() {
		return originalEmdDocNumber1;
	}

	public void setOriginalEmdDocNumber1(String originalEmdDocNumber1) {
		this.originalEmdDocNumber1 = originalEmdDocNumber1;
	}

	public String getOriginalEmdDocNumber2() {
		return originalEmdDocNumber2;
	}

	public void setOriginalEmdDocNumber2(String originalEmdDocNumber2) {
		this.originalEmdDocNumber2 = originalEmdDocNumber2;
	}

	public String getOriginalEmdDocNumber3() {
		return originalEmdDocNumber3;
	}

	public void setOriginalEmdDocNumber3(String originalEmdDocNumber3) {
		this.originalEmdDocNumber3 = originalEmdDocNumber3;
	}

	public String getOriginalEmdDocNumber4() {
		return originalEmdDocNumber4;
	}

	public void setOriginalEmdDocNumber4(String originalEmdDocNumber4) {
		this.originalEmdDocNumber4 = originalEmdDocNumber4;
	}

	public String getOriginalEmdDocNumber5() {
		return originalEmdDocNumber5;
	}

	public void setOriginalEmdDocNumber5(String originalEmdDocNumber5) {
		this.originalEmdDocNumber5 = originalEmdDocNumber5;
	}

	public String getOriginalEmdDocNumber6() {
		return originalEmdDocNumber6;
	}

	public void setOriginalEmdDocNumber6(String originalEmdDocNumber6) {
		this.originalEmdDocNumber6 = originalEmdDocNumber6;
	}

	public String getOriginalEmdDocNumber7() {
		return originalEmdDocNumber7;
	}

	public void setOriginalEmdDocNumber7(String originalEmdDocNumber7) {
		this.originalEmdDocNumber7 = originalEmdDocNumber7;
	}

	public String getOriginalIssueInformation() {
		return originalIssueInformation;
	}

	public void setOriginalIssueInformation(String originalIssueInformation) {
		this.originalIssueInformation = originalIssueInformation;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPaymentCurrency() {
		return paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public String getPenaltyRestrictionIndicator() {
		return penaltyRestrictionIndicator;
	}

	public void setPenaltyRestrictionIndicator(String penaltyRestrictionIndicator) {
		this.penaltyRestrictionIndicator = penaltyRestrictionIndicator;
	}

	public String getPresentCreditCardIndicator() {
		return presentCreditCardIndicator;
	}

	public void setPresentCreditCardIndicator(String presentCreditCardIndicator) {
		this.presentCreditCardIndicator = presentCreditCardIndicator;
	}

	public String getReasonForIssuanceCode() {
		return reasonForIssuanceCode;
	}

	public void setReasonForIssuanceCode(String reasonForIssuanceCode) {
		this.reasonForIssuanceCode = reasonForIssuanceCode;
	}

	public String getReasonForIssuanceSubCode() {
		return reasonForIssuanceSubCode;
	}

	public void setReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		this.reasonForIssuanceSubCode = reasonForIssuanceSubCode;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getReportedFare() {
		return reportedFare;
	}

	public void setReportedFare(String reportedFare) {
		this.reportedFare = reportedFare;
	}

	public String getRevenueAttributionNumber() {
		return revenueAttributionNumber;
	}

	public void setRevenueAttributionNumber(String revenueAttributionNumber) {
		this.revenueAttributionNumber = revenueAttributionNumber;
	}

	public String getSettlementAuthorizationCode() {
		return settlementAuthorizationCode;
	}

	public void setSettlementAuthorizationCode(String settlementAuthorizationCode) {
		this.settlementAuthorizationCode = settlementAuthorizationCode;
	}

	public String getSettlementAuthorizationEmd() {
		return settlementAuthorizationEmd;
	}

	public void setSettlementAuthorizationEmd(String settlementAuthorizationEmd) {
		this.settlementAuthorizationEmd = settlementAuthorizationEmd;
	}

	public String getSoldDestinationCode() {
		return soldDestinationCode;
	}

	public void setSoldDestinationCode(String soldDestinationCode) {
		this.soldDestinationCode = soldDestinationCode;
	}

	public String getSoldLocalDepartDate() {
		return soldLocalDepartDate;
	}

	public void setSoldLocalDepartDate(String soldLocalDepartDate) {
		this.soldLocalDepartDate = soldLocalDepartDate;
	}

	public String getSoldMarketingCarrier() {
		return soldMarketingCarrier;
	}

	public void setSoldMarketingCarrier(String soldMarketingCarrier) {
		this.soldMarketingCarrier = soldMarketingCarrier;
	}

	public String getSoldMarketingFlightNo() {
		return soldMarketingFlightNo;
	}

	public void setSoldMarketingFlightNo(String soldMarketingFlightNo) {
		this.soldMarketingFlightNo = soldMarketingFlightNo;
	}

	public String getSoldOperatingCarrier() {
		return soldOperatingCarrier;
	}

	public void setSoldOperatingCarrier(String soldOperatingCarrier) {
		this.soldOperatingCarrier = soldOperatingCarrier;
	}

	public String getSoldOperatingFlightNo() {
		return soldOperatingFlightNo;
	}

	public void setSoldOperatingFlightNo(String soldOperatingFlightNo) {
		this.soldOperatingFlightNo = soldOperatingFlightNo;
	}

	public String getSoldOriginCode() {
		return soldOriginCode;
	}

	public void setSoldOriginCode(String soldOriginCode) {
		this.soldOriginCode = soldOriginCode;
	}

	public String getStaffResEntitlement() {
		return staffResEntitlement;
	}

	public void setStaffResEntitlement(String staffResEntitlement) {
		this.staffResEntitlement = staffResEntitlement;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTicketingModeIndicator() {
		return ticketingModeIndicator;
	}

	public void setTicketingModeIndicator(String ticketingModeIndicator) {
		this.ticketingModeIndicator = ticketingModeIndicator;
	}

	public String getTourCode() {
		return tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionTotalAmount() {
		return transactionTotalAmount;
	}

	public void setTransactionTotalAmount(String transactionTotalAmount) {
		this.transactionTotalAmount = transactionTotalAmount;
	}

	public String getUsageAirline() {
		return usageAirline;
	}

	public void setUsageAirline(String usageAirline) {
		this.usageAirline = usageAirline;
	}

	public String getUsageDestinationCode() {
		return usageDestinationCode;
	}

	public void setUsageDestinationCode(String usageDestinationCode) {
		this.usageDestinationCode = usageDestinationCode;
	}

	public String getUsageDestinationCodeEmd() {
		return usageDestinationCodeEmd;
	}

	public void setUsageDestinationCodeEmd(String usageDestinationCodeEmd) {
		this.usageDestinationCodeEmd = usageDestinationCodeEmd;
	}

	public String getUsageDocNumber() {
		return usageDocNumber;
	}

	public void setUsageDocNumber(String usageDocNumber) {
		this.usageDocNumber = usageDocNumber;
	}

	public String getUsageEmdDate() {
		return usageEmdDate;
	}

	public void setUsageEmdDate(String usageEmdDate) {
		this.usageEmdDate = usageEmdDate;
	}

	public String getUsageLocalFlightDate() {
		return usageLocalFlightDate;
	}

	public void setUsageLocalFlightDate(String usageLocalFlightDate) {
		this.usageLocalFlightDate = usageLocalFlightDate;
	}

	public String getUsageMarketingCarrierCode() {
		return usageMarketingCarrierCode;
	}

	public void setUsageMarketingCarrierCode(String usageMarketingCarrierCode) {
		this.usageMarketingCarrierCode = usageMarketingCarrierCode;
	}

	public String getUsageOperatingCarrier() {
		return usageOperatingCarrier;
	}

	public void setUsageOperatingCarrier(String usageOperatingCarrier) {
		this.usageOperatingCarrier = usageOperatingCarrier;
	}

	public String getUsageOperatingFlightNumber() {
		return usageOperatingFlightNumber;
	}

	public void setUsageOperatingFlightNumber(String usageOperatingFlightNumber) {
		this.usageOperatingFlightNumber = usageOperatingFlightNumber;
	}

	public String getUsageOperatingFlightSuffix() {
		return usageOperatingFlightSuffix;
	}

	public void setUsageOperatingFlightSuffix(String usageOperatingFlightSuffix) {
		this.usageOperatingFlightSuffix = usageOperatingFlightSuffix;
	}

	public String getUsageOriginCode() {
		return usageOriginCode;
	}

	public void setUsageOriginCode(String usageOriginCode) {
		this.usageOriginCode = usageOriginCode;
	}

	public String getUsageOriginCodeEmd() {
		return usageOriginCodeEmd;
	}

	public void setUsageOriginCodeEmd(String usageOriginCodeEmd) {
		this.usageOriginCodeEmd = usageOriginCodeEmd;
	}

	public String getUsagePerformer() {
		return usagePerformer;
	}

	public void setUsagePerformer(String usagePerformer) {
		this.usagePerformer = usagePerformer;
	}

	public String getUsageType() {
		return usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public String getUsageUtcFlightDate() {
		return usageUtcFlightDate;
	}

	public void setUsageUtcFlightDate(String usageUtcFlightDate) {
		this.usageUtcFlightDate = usageUtcFlightDate;
	}

	public String getUsedCabinClass() {
		return usedCabinClass;
	}

	public void setUsedCabinClass(String usedCabinClass) {
		this.usedCabinClass = usedCabinClass;
	}

	public List<AmadeusOldTaxStaging> getAmadeusOldTaxStgs() {
		return amadeusOldTaxStgs;
	}

	public void setAmadeusOldTaxStgs(List<AmadeusOldTaxStaging> amadeusOldTaxStgs) {
		this.amadeusOldTaxStgs = amadeusOldTaxStgs;
	}

	public List<AmadeusRecordDetailStaging> getAmadeusRecordDetailStgs() {
		return amadeusRecordDetailStgs;
	}

	public void setAmadeusRecordDetailStgs(List<AmadeusRecordDetailStaging> amadeusRecordDetailStgs) {
		this.amadeusRecordDetailStgs = amadeusRecordDetailStgs;
	}

	public List<AmadeusRecordExchDetailStaging> getAmadeusRecordExchDetailStgs() {
		return amadeusRecordExchDetailStgs;
	}

	public void setAmadeusRecordExchDetailStgs(List<AmadeusRecordExchDetailStaging> amadeusRecordExchDetailStgs) {
		this.amadeusRecordExchDetailStgs = amadeusRecordExchDetailStgs;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

}