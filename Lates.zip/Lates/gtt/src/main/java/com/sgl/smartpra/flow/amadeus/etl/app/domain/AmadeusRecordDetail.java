package com.sgl.smartpra.flow.amadeus.etl.app.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * The persistent class for the amadeus_record_detail_stg database table.
 * 
 */

public class AmadeusRecordDetail extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private int amadeusCpnDtlId;

	private String airlineCode;

	private String consumedAtIssuanceIndicator;

	private String couponNumber;

	private String couponValue;
	
	private String destination;

	private String ebtChargeCurrency;

	private String ebtChargeQualify;

	private String ebtRatePerUnit;

	private String ebtUnitQualifier;

	private String emdTotalNoOfUnits;

	private String fareBasis;

	private String feeOwner;

	private String flightArrivalDate;

	private String freeBaggageAllowance;

	private String invlCouponNo;

	private String invlDestinationAirport;

	private String invlDisruptionIndicator;

	private String invlDocNo;

	private String invlFlightDate;

	private String invlFlightDepartTime;

	private String invlFlightNumber;

	private String invlMarketingCarrierCode;

	private String invlOriginAirportCode;

	private String invlReservationBkng;

	private String invlStopoverCode;

	private String involuntaryIndicator;

	private String nonExchangeableIndicator;

	private String nonInterlinableIndicator;

	private String notValidAfterDate;

	private String notValidBeforeDate;

	private String origin;

	private String reasonForIssuanceSubCode;

	private String reservationStatus;

	private String saleCouponNumber;

	private String saleFlightNumber;

	private String saleLocalFlightDate;

	private String sellingClass;

	private String stopOverCode;

	
	private AmadeusRecordStaging amadeusRecordStg;

	

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getAmadeusCpnDtlId() {
		return amadeusCpnDtlId;
	}

	public void setAmadeusCpnDtlId(int amadeusCpnDtlId) {
		this.amadeusCpnDtlId = amadeusCpnDtlId;
	}

	public String getAirlineCode() {
		return airlineCode;
	}

	public void setAirlineCode(String airlineCode) {
		this.airlineCode = airlineCode;
	}

	public String getConsumedAtIssuanceIndicator() {
		return consumedAtIssuanceIndicator;
	}

	public void setConsumedAtIssuanceIndicator(String consumedAtIssuanceIndicator) {
		this.consumedAtIssuanceIndicator = consumedAtIssuanceIndicator;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponValue() {
		return couponValue;
	}

	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getEbtChargeCurrency() {
		return ebtChargeCurrency;
	}

	public void setEbtChargeCurrency(String ebtChargeCurrency) {
		this.ebtChargeCurrency = ebtChargeCurrency;
	}

	public String getEbtChargeQualify() {
		return ebtChargeQualify;
	}

	public void setEbtChargeQualify(String ebtChargeQualify) {
		this.ebtChargeQualify = ebtChargeQualify;
	}

	public String getEbtRatePerUnit() {
		return ebtRatePerUnit;
	}

	public void setEbtRatePerUnit(String ebtRatePerUnit) {
		this.ebtRatePerUnit = ebtRatePerUnit;
	}

	public String getEbtUnitQualifier() {
		return ebtUnitQualifier;
	}

	public void setEbtUnitQualifier(String ebtUnitQualifier) {
		this.ebtUnitQualifier = ebtUnitQualifier;
	}

	public String getEmdTotalNoOfUnits() {
		return emdTotalNoOfUnits;
	}

	public void setEmdTotalNoOfUnits(String emdTotalNoOfUnits) {
		this.emdTotalNoOfUnits = emdTotalNoOfUnits;
	}

	public String getFareBasis() {
		return fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getFeeOwner() {
		return feeOwner;
	}

	public void setFeeOwner(String feeOwner) {
		this.feeOwner = feeOwner;
	}

	public String getFlightArrivalDate() {
		return flightArrivalDate;
	}

	public void setFlightArrivalDate(String flightArrivalDate) {
		this.flightArrivalDate = flightArrivalDate;
	}

	public String getFreeBaggageAllowance() {
		return freeBaggageAllowance;
	}

	public void setFreeBaggageAllowance(String freeBaggageAllowance) {
		this.freeBaggageAllowance = freeBaggageAllowance;
	}

	public String getInvlCouponNo() {
		return invlCouponNo;
	}

	public void setInvlCouponNo(String invlCouponNo) {
		this.invlCouponNo = invlCouponNo;
	}

	public String getInvlDestinationAirport() {
		return invlDestinationAirport;
	}

	public void setInvlDestinationAirport(String invlDestinationAirport) {
		this.invlDestinationAirport = invlDestinationAirport;
	}

	public String getInvlDisruptionIndicator() {
		return invlDisruptionIndicator;
	}

	public void setInvlDisruptionIndicator(String invlDisruptionIndicator) {
		this.invlDisruptionIndicator = invlDisruptionIndicator;
	}

	public String getInvlDocNo() {
		return invlDocNo;
	}

	public void setInvlDocNo(String invlDocNo) {
		this.invlDocNo = invlDocNo;
	}

	public String getInvlFlightDate() {
		return invlFlightDate;
	}

	public void setInvlFlightDate(String invlFlightDate) {
		this.invlFlightDate = invlFlightDate;
	}

	public String getInvlFlightDepartTime() {
		return invlFlightDepartTime;
	}

	public void setInvlFlightDepartTime(String invlFlightDepartTime) {
		this.invlFlightDepartTime = invlFlightDepartTime;
	}

	public String getInvlFlightNumber() {
		return invlFlightNumber;
	}

	public void setInvlFlightNumber(String invlFlightNumber) {
		this.invlFlightNumber = invlFlightNumber;
	}

	public String getInvlMarketingCarrierCode() {
		return invlMarketingCarrierCode;
	}

	public void setInvlMarketingCarrierCode(String invlMarketingCarrierCode) {
		this.invlMarketingCarrierCode = invlMarketingCarrierCode;
	}

	public String getInvlOriginAirportCode() {
		return invlOriginAirportCode;
	}

	public void setInvlOriginAirportCode(String invlOriginAirportCode) {
		this.invlOriginAirportCode = invlOriginAirportCode;
	}

	public String getInvlReservationBkng() {
		return invlReservationBkng;
	}

	public void setInvlReservationBkng(String invlReservationBkng) {
		this.invlReservationBkng = invlReservationBkng;
	}

	public String getInvlStopoverCode() {
		return invlStopoverCode;
	}

	public void setInvlStopoverCode(String invlStopoverCode) {
		this.invlStopoverCode = invlStopoverCode;
	}

	public String getInvoluntaryIndicator() {
		return involuntaryIndicator;
	}

	public void setInvoluntaryIndicator(String involuntaryIndicator) {
		this.involuntaryIndicator = involuntaryIndicator;
	}

	public String getNonExchangeableIndicator() {
		return nonExchangeableIndicator;
	}

	public void setNonExchangeableIndicator(String nonExchangeableIndicator) {
		this.nonExchangeableIndicator = nonExchangeableIndicator;
	}

	public String getNonInterlinableIndicator() {
		return nonInterlinableIndicator;
	}

	public void setNonInterlinableIndicator(String nonInterlinableIndicator) {
		this.nonInterlinableIndicator = nonInterlinableIndicator;
	}

	public String getNotValidAfterDate() {
		return notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getNotValidBeforeDate() {
		return notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getReasonForIssuanceSubCode() {
		return reasonForIssuanceSubCode;
	}

	public void setReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		this.reasonForIssuanceSubCode = reasonForIssuanceSubCode;
	}

	public String getReservationStatus() {
		return reservationStatus;
	}

	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}

	public String getSaleCouponNumber() {
		return saleCouponNumber;
	}

	public void setSaleCouponNumber(String saleCouponNumber) {
		this.saleCouponNumber = saleCouponNumber;
	}

	public String getSaleFlightNumber() {
		return saleFlightNumber;
	}

	public void setSaleFlightNumber(String saleFlightNumber) {
		this.saleFlightNumber = saleFlightNumber;
	}

	public String getSaleLocalFlightDate() {
		return saleLocalFlightDate;
	}

	public void setSaleLocalFlightDate(String saleLocalFlightDate) {
		this.saleLocalFlightDate = saleLocalFlightDate;
	}

	public String getSellingClass() {
		return sellingClass;
	}

	public void setSellingClass(String sellingClass) {
		this.sellingClass = sellingClass;
	}

	public String getStopOverCode() {
		return stopOverCode;
	}

	public void setStopOverCode(String stopOverCode) {
		this.stopOverCode = stopOverCode;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

}