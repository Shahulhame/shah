package com.sgl.smartpra.flow.amadeus.etl.app.domain;

public class CouponDetails {

	private String issAirline;

	private String documentNumber;

	private String couponNumber;

	private String coupons;

	public String getIssAirline() {
		return issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCoupons() {
		return coupons;
	}

	public void setCoupons(String coupons) {
		this.coupons = coupons;
	}

	@Override
	public String toString() {
		return "CouponDetails [issAirline=" + issAirline + ", documentNumber=" + documentNumber + ", couponNumber="
				+ couponNumber + ", coupons=" + coupons + "]";
	}

	
}
