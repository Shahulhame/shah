package com.sgl.smartpra.batch.flown.amadeus.etl.app.config;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.annotation.BeforeJob;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.support.ClassifierCompositeItemProcessor;
import org.springframework.batch.item.support.ClassifierCompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.PlatformTransactionManager;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.listener.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
@EntityScan("com.sgl.smartpra.batch.flown.amadeus.etl.app")
@EnableJpaRepositories(basePackages = "com.sgl.smartpra.batch.flown.amadeus.etl.app.repository")
@ComponentScan({ "com.sgl.smartpra.batch.flown.amadeus.etl.app" })
@EnableAutoConfiguration
public class AmadeusEtlBatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(AmadeusEtlBatchConfiguration.class);

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	EntityManagerFactory emf;

	@Value("${batch-input-dir}")
	private String batchInputDir;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Bean
	public TaskExecutor taskExecutor() {
		SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
		return taskExecutor;
	}
	

	
	@Bean
	public Job importAmadeusJob(JobCompletionNotificationListener listener, Step importAmadeusData,Step importAmadeusEMDData) {
		log.info("Entering Batch Config");
System.out.println("Entering JOB+++++++++++++++>");
		return jobBuilderFactory.get("importAmadeusJob").incrementer(new RunIdIncrementer()).listener(listener)
				.flow(importAmadeusData).next(importAmadeusEMDData).end().build();
	}

	@SuppressWarnings("unchecked")
	@Bean
	public Step importAmadeusData() {
		return stepBuilderFactory.get("AmadeusEtlRecord").<AmadeusEtlRecord, AmadeusEtlRecord>chunk(100)
				.reader(amadeusItemReader(null))
				.processor((ItemProcessor<? super AmadeusEtlRecord, ? extends AmadeusEtlRecord>) amadeusProcessor(
						amadeusRecordStagingProcessor()))
				.writer((ItemWriter<? super AmadeusEtlRecord>) amadeusWriter(amadeusRecordStagingWriter()))
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).build();
	}
	
	
	
	
	
	@SuppressWarnings("unchecked")
	@Bean
	public Step importAmadeusEMDData() {
		return stepBuilderFactory.get("AmadeusEtlRecord").<AmadeusEtlRecord, AmadeusEtlRecord>chunk(100)
				.reader(amadeusItemReader(null))
				.processor((ItemProcessor<? super AmadeusEtlRecord, ? extends AmadeusEtlRecord>) amadeusProcessor(
						amadeusRecordStagingProcessor()))
				.writer((ItemWriter<? super AmadeusEtlRecord>) amadeusWriter(amadeusRecordStagingEmdWriter()))
				.transactionManager(transactionManager).taskExecutor(taskExecutor()).build();
	}
	
	
	

	@Bean
	@StepScope
	public FlatFileItemReader<AmadeusEtlRecord> amadeusItemReader(
			@Value("#{jobParameters[inboundFileName]}") String fileName) {

		FlatFileItemReader<AmadeusEtlRecord> reader = new FlatFileItemReader<AmadeusEtlRecord>();
		reader.setResource(new FileSystemResource( batchInputDir+ "/" + fileName));
		reader.setLinesToSkip(1);
		reader.setLineMapper(amadeusLineMapper());
		return reader;
	}
	
	

	@Bean
	public LineMapper<AmadeusEtlRecord> amadeusLineMapper() {
		PatternMatchingCompositeLineMapper<AmadeusEtlRecord> mapper = new PatternMatchingCompositeLineMapper<>();

		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("9*", (new AmadeusRecordStaging()).lineTokenizer());

		mapper.setTokenizers(tokenizers);

		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());

		mapper.setFieldSetMappers(mappers);
		return mapper;
	}

	@Bean
	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter() {
		return new AmadeusRecordStaging().writer();
	}
	
	@Bean
	public ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingEmdWriter() {
		return new AmadeusRecordStaging().writer();
	}
	
	

	@SuppressWarnings("serial")
	@Bean
	public ClassifierCompositeItemWriter<? extends AmadeusEtlRecord> amadeusWriter(
			ItemWriter<? super AmadeusEtlRecord> amadeusRecordStagingWriter

	) {
		ClassifierCompositeItemWriter<AmadeusEtlRecord> classifierCompositeItemWriter = new ClassifierCompositeItemWriter<>();
		classifierCompositeItemWriter
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemWriter<? super AmadeusEtlRecord>>() {

					@Override
					public ItemWriter<? super AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordStaging) {
							return amadeusRecordStagingWriter();
						}
						else if  (classifiable instanceof AmadeusRecordStaging) {
							return amadeusRecordStagingEmdWriter();
						}
						

						return null;
					}

				});
		return classifierCompositeItemWriter;
	}

	@Bean
	@StepScope
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor() {
		return new AmadeusRecordStaging().processor();
	}

	@SuppressWarnings("serial")
	@Bean
	@StepScope
	public ClassifierCompositeItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusProcessor(
			ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> amadeusRecordStagingProcessor

	) {
		ClassifierCompositeItemProcessor<AmadeusEtlRecord, AmadeusEtlRecord> classifierCompositeItemProcessor = new ClassifierCompositeItemProcessor<>();
		classifierCompositeItemProcessor
				.setClassifier(new Classifier<AmadeusEtlRecord, ItemProcessor<?, ? extends AmadeusEtlRecord>>() {

					@Override
					public ItemProcessor<?, ? extends AmadeusEtlRecord> classify(AmadeusEtlRecord classifiable) {
						if (classifiable instanceof AmadeusRecordStaging) {
							return amadeusRecordStagingProcessor;

						}
						return null;

					}

				});
		return classifierCompositeItemProcessor;

	}

}
