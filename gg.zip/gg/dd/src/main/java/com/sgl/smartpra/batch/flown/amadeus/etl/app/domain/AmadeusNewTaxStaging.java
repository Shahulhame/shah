package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.layout.AmadeusRecordStagingLayout;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.processor.AmadeusRecordStagingProcessor;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.writer.AmadeusRecordStagingWriter;


/**
 * The persistent class for the amadeus_old_tax_stg database table.
 * 
 */
@Entity
@Table(name="amadeus_new_tax_stg")
@NamedQuery(name="AmadeusNewTaxStaging.findAll", query="SELECT a FROM AmadeusNewTaxStaging a")
public class AmadeusNewTaxStaging extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="amadeus_new_tax_id")
	private int amadeus_new_tax_id;

	
	@Column(name="new_tax_code")
	private String newTaxCode;

	@Column(name="new_tax_value")
	private String newTaxValue;

	//bi-directional many-to-one association to AmadeusRecordStg
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "amadeus_load_id", referencedColumnName = "amadeus_load_id")
	private AmadeusRecordStaging amadeusRecordStg;

	public AmadeusNewTaxStaging() {
	}

	public int getAmadeus_new_tax_id() {
		return amadeus_new_tax_id;
	}

	public void setAmadeus_new_tax_id(int amadeus_new_tax_id) {
		this.amadeus_new_tax_id = amadeus_new_tax_id;
	}

	public String getNewTaxCode() {
		return newTaxCode;
	}

	public void setNewTaxCode(String newTaxCode) {
		this.newTaxCode = newTaxCode;
	}

	public String getNewTaxValue() {
		return newTaxValue;
	}

	public void setNewTaxValue(String newTaxValue) {
		this.newTaxValue = newTaxValue;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AmadeusRecordStagingLayout amadeusRecordStagingLayout = new AmadeusRecordStagingLayout();
		tokenizer.setColumns(amadeusRecordStagingLayout.getColumns());
		tokenizer.setNames(amadeusRecordStagingLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<AmadeusEtlRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<AmadeusEtlRecord>();
		fieldSetMapper.setTargetType(AmadeusNewTaxStaging.class);
		return fieldSetMapper;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		return new AmadeusRecordStagingProcessor();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		return new AmadeusRecordStagingWriter();
	}
	
	

}