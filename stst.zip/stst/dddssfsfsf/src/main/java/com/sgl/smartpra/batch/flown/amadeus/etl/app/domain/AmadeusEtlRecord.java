package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

@MappedSuperclass
public abstract class AmadeusEtlRecord {

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_date")
	private Timestamp createdDate;
	
	@Column(name = "inbound_file_id")
	private int inboundFileId;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;
	
	@Column(name = "file_source")
	private String fileSource;
	
	@Column(name = "status")
	private String status;

	
	
	

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public int getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(int inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getFileSource() {
		return fileSource;
	}

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public abstract LineTokenizer lineTokenizer();

	public abstract FieldSetMapper<AmadeusEtlRecord> fieldSetMapper();

	public abstract ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor();

	public abstract ItemWriter<? super AmadeusEtlRecord> amadeusEtlwriter();
	
	public abstract ItemWriter<? super AmadeusEtlRecord> amadeusEmdwriter();
	
	public abstract LineTokenizer emdLineTokenizer();

	

}
