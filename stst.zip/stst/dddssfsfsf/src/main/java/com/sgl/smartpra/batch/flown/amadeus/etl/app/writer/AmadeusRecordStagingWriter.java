package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordDetailStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.SharedEntity;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusRecordStagingRepository;

@Component
public class AmadeusRecordStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusRecordStaging> {

	@Autowired
	private AmadeusRecordStagingRepository amadeusRecordStagingRepository;

	@Autowired
	private SharedEntity sharedEntity;
	
    public static final  String CREATED_BY="Amadeus";
	
	public static final  String FILE_SOURCE="ETL";
	
	public static final  String STATUS="N";

	@SuppressWarnings("unchecked")
	@Override
	public void write(List<? extends AmadeusRecordStaging> amadeusRecordStagingList) throws Exception {
		amadeusRecordStagingList = amadeusRecordStagingRepository
				.saveAll((List<AmadeusRecordStaging>) amadeusRecordStagingList);
		AmadeusRecordStaging amadeusRecordStaging = (AmadeusRecordStaging) amadeusRecordStagingList.get(0);
		sharedEntity.setAmadeusRecordStaging(amadeusRecordStaging);
		ArrayList<AmadeusRecordDetailStaging> amadeusRecordDetailStagingList;
		ArrayList<AmadeusNewTaxStaging> amadeusNewTaxStagingList;
		String couponNumber;
		AmadeusRecordDetailStaging amadeusRecordDetailStaging;
		AmadeusNewTaxStaging amadeusNewTaxStaging;
		for (int j = 0; j < amadeusRecordStagingList.size(); j++) {
			sharedEntity.setAmadeusRecordStaging(amadeusRecordStaging);
			amadeusRecordStaging = (AmadeusRecordStaging) amadeusRecordStagingList.get(j);

			// New Tax Details
			amadeusNewTaxStagingList = new ArrayList<AmadeusNewTaxStaging>();
			String taxDetailStr = amadeusRecordStaging.getNewTax();
			int taxCount = taxDetailStr.length() / 14;
			for (int k = 0; k < taxCount; k++) {

				amadeusNewTaxStaging = new AmadeusNewTaxStaging();
				amadeusNewTaxStaging.setNewTaxCode(taxDetailStr.substring((k * 14), (k * 14) + 2));
				amadeusNewTaxStaging.setNewTaxValue(taxDetailStr.substring((k * 14) + 2, (k * 14) + 14));
				amadeusNewTaxStaging.setCreatedBy(CREATED_BY);
				amadeusNewTaxStaging.setFileSource(FILE_SOURCE);
				amadeusNewTaxStaging.setCreatedDate(new Timestamp(new Date().getTime()));
				amadeusNewTaxStaging.setStatus(STATUS);

				amadeusNewTaxStaging.setAmadeusRecordStg(sharedEntity.getAmadeusRecordStaging());
				amadeusNewTaxStagingList.add(amadeusNewTaxStaging);

			}

			// Coupon table
			amadeusRecordDetailStagingList = new ArrayList<AmadeusRecordDetailStaging>();
			String couponDetailStr = amadeusRecordStaging.getCoupons();
			int couponCount = couponDetailStr.length() / 62;
			for (int i = 0; i < couponCount; i++) {
				System.out.println("Enter into AmadeusDetail");
				couponNumber = couponDetailStr.substring((i * 62), (i * 62) + 2);
				if (couponNumber != null && couponNumber.length() > 0) {
					amadeusRecordDetailStaging = new AmadeusRecordDetailStaging();
					amadeusRecordDetailStaging.setCouponNumber(amadeusRecordStaging.getCouponNumber());
					amadeusRecordDetailStaging.setSaleCouponNumber(couponNumber);
					amadeusRecordDetailStaging.setOrigin(couponDetailStr.substring((i * 62) + 2, (i * 62) + 7));
					amadeusRecordDetailStaging.setDestination(couponDetailStr.substring((i * 62) + 7, (i * 62) + 12));
					amadeusRecordDetailStaging.setAirlineCode(couponDetailStr.substring((i * 62) + 12, (i * 62) + 15));
					amadeusRecordDetailStaging
							.setSaleFlightNumber(couponDetailStr.substring((i * 62) + 15, (i * 62) + 20));
					amadeusRecordDetailStaging
							.setSaleLocalFlightDate(couponDetailStr.substring((i * 62) + 20, (i * 62) + 26));

					amadeusRecordDetailStaging.setSellingClass(couponDetailStr.substring((i * 62) + 26, (i * 62) + 28));

					amadeusRecordDetailStaging.setFareBasis(couponDetailStr.substring((i * 62) + 28, (i * 62) + 43));
					amadeusRecordDetailStaging
							.setReservationStatus(couponDetailStr.substring((i * 62) + 43, (i * 62) + 45));
					amadeusRecordDetailStaging
							.setFreeBaggageAllowance(couponDetailStr.substring((i * 62) + 45, (i * 62) + 48));
					amadeusRecordDetailStaging
							.setInvoluntaryIndicator(couponDetailStr.substring((i * 62) + 48, (i * 62) + 49));
					amadeusRecordDetailStaging.setStopOverCode(couponDetailStr.substring((i * 62) + 49, (i * 62) + 50));
					amadeusRecordDetailStaging
							.setNotValidBeforeDate(couponDetailStr.substring((i * 62) + 50, (i * 62) + 56));
					amadeusRecordDetailStaging
							.setNotValidAfterDate(couponDetailStr.substring((i * 62) + 56, (i * 62) + 62));
					amadeusRecordDetailStaging.setCreatedBy(CREATED_BY);
					amadeusRecordDetailStaging.setFileSource(FILE_SOURCE);
					amadeusRecordDetailStaging.setCreatedDate(new Timestamp(new Date().getTime()));
					amadeusRecordDetailStaging.setStatus(STATUS);
					amadeusRecordDetailStaging.setAmadeusRecordStg(sharedEntity.getAmadeusRecordStaging());
					amadeusRecordDetailStagingList.add(amadeusRecordDetailStaging);
				} else {
					break;
				}
			}
			// Add coupon
			amadeusRecordStaging.setAmadeusRecordDetailStgs(amadeusRecordDetailStagingList);
			// Tax Details
			amadeusRecordStaging.setAmadeusNewTaxStgs(amadeusNewTaxStagingList);
		}
		amadeusRecordStagingRepository.saveAll(amadeusRecordStagingList);
		amadeusRecordStagingRepository.flush();
	}

}
