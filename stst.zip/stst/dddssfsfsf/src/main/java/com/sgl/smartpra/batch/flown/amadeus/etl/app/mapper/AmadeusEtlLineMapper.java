package com.sgl.smartpra.batch.flown.amadeus.etl.app.mapper;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.mapping.PatternMatchingCompositeLineMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordStaging;


@Component
public class AmadeusEtlLineMapper implements LineMapper<AmadeusEtlRecord> {

	public AmadeusEtlLineMapper() {
	
	}

	PatternMatchingCompositeLineMapper<AmadeusEtlRecord> lineMap = new PatternMatchingCompositeLineMapper<>();
	public void setTokenizers() {
		
		System.out.println("Entering Tokenizers--------->");
		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>(10);
		tokenizers.put("1*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("2*", (new AmadeusRecordStaging()).lineTokenizer());
		tokenizers.put("9*", (new AmadeusRecordStaging()).lineTokenizer());

		lineMap.setTokenizers(tokenizers);
	}

	public void setFieldSetMappers() {
		Map<String, FieldSetMapper<AmadeusEtlRecord>> mappers = new HashMap<String, FieldSetMapper<AmadeusEtlRecord>>();
		mappers.put("1*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("2*", (new AmadeusRecordStaging()).fieldSetMapper());
		mappers.put("9*", (new AmadeusRecordStaging()).fieldSetMapper());
		lineMap.setFieldSetMappers(mappers);
	}

	@Override
	public AmadeusEtlRecord mapLine(String line, int lineNumber) throws Exception {
		return null;
	}

	

}
