package com.sgl.smartpra.batch.flown.amadeus.etl.app.processor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;


@Component
@Scope(value="step")
public class AmadeusProcessor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final  String CREATED_BY="Amadeus";
	
	public static final  String FILE_SOURCE="ETL";
	
	public static final  String STATUS="N";

	@Value("#{jobParameters['inboundFileId']}")
	public Integer inboundFileId;

	public Integer getInboundFileId() {
		return inboundFileId;
	}

	public void setInboundFileId(Integer inboundFileId) {
		this.inboundFileId = inboundFileId;
	}

	public void process(AmadeusEtlRecord amadeusEtlRecord) {
		
		
		amadeusEtlRecord.setCreatedBy(CREATED_BY);
		amadeusEtlRecord.setCreatedDate(new Timestamp(new Date().getTime()));
		amadeusEtlRecord.setFileSource(FILE_SOURCE);
		amadeusEtlRecord.setStatus(STATUS);

	}
}
