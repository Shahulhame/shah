package com.JCG.model;

import org.springframework.data.jpa.repository.JpaRepository;

import com.JCG.model.UsersContact;

public interface UsersContactRepository extends JpaRepository<UsersContact, Integer> {
}
