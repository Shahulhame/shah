package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.layout.AmadeusRecordStagingLayout;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.processor.AmadeusRecordStagingProcessor;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.writer.AmadeusRecordStagingWriter;

/**
 * The persistent class for the amadeus_record_stg database table.
 * 
 */
@Entity
@Table(name = "amadeus_record_stg")
@NamedQuery(name = "AmadeusRecordStaging.findAll", query = "SELECT a FROM AmadeusRecordStaging a")
public class AmadeusRecordStaging extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "amadeus_load_id")
	private int amadeusLoadId;

	@Column(name = "additional_collection_total")
	private String additionalCollectionTotal;

	@Column(name = "additional_information")
	private String additionalInformation;

	@Column(name = "agency_number")
	private String agencyNumber;

	@Column(name = "airline_change_performer")
	private String airlineChangePerformer;

	@Column(name = "airline_code_emd")
	private String airlineCodeEmd;

	@Column(name = "amount_entered_by_agent")
	private String amountEnteredByAgent;

	@Column(name = "approved_collection_code")
	private String approvedCollectionCode;

	@Column(name = "approved_collection_code2")
	private String approvedCollectionCode2;

	@Column(name = "approved_collection_code3")
	private String approvedCollectionCode3;

	@Column(name = "association_status")
	private String associationStatus;

	@Column(name = "bankers_exchange_rate")
	private String bankersExchangeRate;

	@Column(name = "booking_reference")
	private String bookingReference;

	@Column(name = "check_digit")
	private String checkDigit;

	@Column(name = "commission_amount")
	private String commissionAmount;

	@Column(name = "commission_rate")
	private String commissionRate;

	@Column(name = "coupon_number")
	private String couponNumber;

	@Column(name = "coupon_revenue_indicator")
	private String couponRevenueIndicator;

	@Column(name = "coupon_sls_indicator")
	private String couponSlsIndicator;

	@Column(name = "coupon_value")
	private String couponValue;

	@Column(name = "curr_of_amt_entered_by_agent")
	private String currOfAmtEnteredByAgent;

	@Column(name = "currency_of_addl_collection")
	private String currencyOfAddlCollection;

	@Column(name = "currency_of_commission_amount")
	private String currencyOfCommissionAmount;

	@Column(name = "currency_of_net_fare")
	private String currencyOfNetFare;

	@Column(name = "currency_of_reported_fare")
	private String currencyOfReportedFare;

	@Column(name = "currency_of_trans_total_amt")
	private String currencyOfTransTotalAmt;

	@Column(name = "document_number")
	private String documentNumber;

	@Column(name = "document_type")
	private String documentType;

	@Column(name = "ebd_charge_currency")
	private String ebdChargeCurrency;

	@Column(name = "ebd_charge_qualifier")
	private String ebdChargeQualifier;

	@Column(name = "ebd_rate_per_unit")
	private String ebdRatePerUnit;

	@Column(name = "ebd_total_no_of_units")
	private String ebdTotalNoOfUnits;

	@Column(name = "ebd_unit_qualifier")
	private String ebdUnitQualifier;

	@Column(name = "emd_document_amount")
	private String emdDocumentAmount;

	@Column(name = "emd_document_amount_currency")
	private String emdDocumentAmountCurrency;

	@Column(name = "endorsement_restriction_text")
	private String endorsementRestrictionText;

	@Column(name = "equivalent_fare")
	private String equivalentFare;

	@Column(name = "fare_basis")
	private String fareBasis;

	@Column(name = "fare_calc_mode_indicator")
	private String fareCalcModeIndicator;

	@Column(name = "fare_construction")
	private String fareConstruction;

	@Column(name = "file_id")
	private int fileId;

	@Column(name = "file_source")
	private String fileSource;

	@Column(name = "flight_number")
	private String flightNumber;

	@Column(name = "form_of_ident_vendor_code")
	private String formOfIdentVendorCode;

	@Column(name = "form_of_identification_number")
	private String formOfIdentificationNumber;

	@Column(name = "form_of_identification_type")
	private String formOfIdentificationType;

	@Column(name = "form_of_payment")
	private String formOfPayment;

	@Column(name = "form_of_payment_2")
	private String formOfPayment2;

	@Column(name = "form_of_payment_3")
	private String formOfPayment3;

	@Column(name = "frequent_flyer_airline_code")
	private String frequentFlyerAirlineCode;

	@Column(name = "frequent_flyer_customer_code")
	private String frequentFlyerCustomerCode;

	@Column(name = "in_connection_coupon_no")
	private String inConnectionCouponNo;

	@Column(name = "in_connection_doc_no")
	private String inConnectionDocNo;

	@Column(name = "international_domestic_ind")
	private String internationalDomesticInd;

	@Column(name = "international_sale_indicaor")
	private String internationalSaleIndicaor;

	@Column(name = "iss_airline")
	private String issAirline;

	@Column(name = "issue_date")
	private String issueDate;

	@Column(name = "issuing_office_location")
	private String issuingOfficeLocation;

	@Column(name = "local_departure_date")
	private String localDepartureDate;

	@Column(name = "manual_indicator")
	private String manualIndicator;

	@Column(name = "net_fare")
	private String netFare;

	@Column(name = "net_remit_indicator")
	private String netRemitIndicator;

	@Column(name = "net_reporting_indicator")
	private String netReportingIndicator;

	@Column(name = "non_endorsable_indicator")
	private String nonEndorsableIndicator;

	@Column(name = "non_exchangeable_amount")
	private String nonExchangeableAmount;

	@Column(name = "non_exchangeable_amt_curr")
	private String nonExchangeableAmtCurr;

	@Column(name = "non_refundable_amount")
	private String nonRefundableAmount;

	@Column(name = "non_refundable_amount_curr")
	private String nonRefundableAmountCurr;

	@Column(name = "non_refundable_indicator")
	private String nonRefundableIndicator;

	@Column(name = "not_valid_after_date")
	private String notValidAfterDate;

	@Column(name = "not_valid_before_date")
	private String notValidBeforeDate;

	@Column(name = "old_approved_collection_code1")
	private String oldApprovedCollectionCode1;

	@Column(name = "old_approved_collection_code2")
	private String oldApprovedCollectionCode2;

	@Column(name = "old_approved_collection_code3")
	private String oldApprovedCollectionCode3;

	@Column(name = "old_form_of_payment")
	private String oldFormOfPayment;

	@Column(name = "old_form_of_payment_2")
	private String oldFormOfPayment2;

	@Column(name = "old_form_of_payment_3")
	private String oldFormOfPayment3;

	@Column(name = "original_emd_doc_number_1")
	private String originalEmdDocNumber1;

	@Column(name = "original_emd_doc_number_2")
	private String originalEmdDocNumber2;

	@Column(name = "original_emd_doc_number_3")
	private String originalEmdDocNumber3;

	@Column(name = "original_emd_doc_number_4")
	private String originalEmdDocNumber4;

	@Column(name = "original_emd_doc_number_5")
	private String originalEmdDocNumber5;

	@Column(name = "original_emd_doc_number_6")
	private String originalEmdDocNumber6;

	@Column(name = "original_emd_doc_number_7")
	private String originalEmdDocNumber7;

	@Column(name = "original_issue_information")
	private String originalIssueInformation;

	@Column(name = "passenger_name")
	private String passengerName;

	@Column(name = "payment_currency")
	private String paymentCurrency;

	@Column(name = "penalty_restriction_indicator")
	private String penaltyRestrictionIndicator;

	@Column(name = "present_credit_card_indicator")
	private String presentCreditCardIndicator;

	@Column(name = "reason_for_issuance_code")
	private String reasonForIssuanceCode;

	@Column(name = "reason_for_issuance_sub_code")
	private String reasonForIssuanceSubCode;

	@Column(name = "record_type")
	private String recordType;

	@Column(name = "reported_fare")
	private String reportedFare;

	@Column(name = "revenue_attribution_number")
	private String revenueAttributionNumber;

	@Column(name = "settlement_authorization_code")
	private String settlementAuthorizationCode;

	@Column(name = "settlement_authorization_emd")
	private String settlementAuthorizationEmd;

	@Column(name = "sold_destination_code")
	private String soldDestinationCode;

	@Column(name = "sold_local_depart_date")
	private String soldLocalDepartDate;

	@Column(name = "sold_marketing_carrier")
	private String soldMarketingCarrier;

	@Column(name = "sold_marketing_flight_no")
	private String soldMarketingFlightNo;

	@Column(name = "sold_operating_carrier")
	private String soldOperatingCarrier;

	@Column(name = "sold_operating_flight_no")
	private String soldOperatingFlightNo;

	@Column(name = "sold_origin_code")
	private String soldOriginCode;

	@Column(name = "staff_res_entitlement")
	private String staffResEntitlement;

	private String status;

	@Column(name = "ticketing_mode_indicator")
	private String ticketingModeIndicator;

	@Column(name = "tour_code")
	private String tourCode;

	@Column(name = "transaction_total_amount")
	private String transactionTotalAmount;

	@Column(name = "usage_airline")
	private String usageAirline;

	@Column(name = "usage_destination_code")
	private String usageDestinationCode;

	@Column(name = "usage_destination_code_emd")
	private String usageDestinationCodeEmd;

	@Column(name = "usage_doc_number")
	private String usageDocNumber;

	@Column(name = "usage_emd_date")
	private String usageEmdDate;

	@Column(name = "usage_local_flight_date")
	private String usageLocalFlightDate;

	@Column(name = "usage_marketing_carrier_code")
	private String usageMarketingCarrierCode;

	@Column(name = "usage_operating_carrier")
	private String usageOperatingCarrier;

	@Column(name = "usage_operating_flight_number")
	private String usageOperatingFlightNumber;

	@Column(name = "usage_operating_flight_suffix")
	private String usageOperatingFlightSuffix;

	@Column(name = "usage_origin_code")
	private String usageOriginCode;

	@Column(name = "usage_origin_code_emd")
	private String usageOriginCodeEmd;

	@Column(name = "usage_performer")
	private String usagePerformer;

	@Column(name = "usage_type")
	private String usageType;

	@Column(name = "usage_utc_flight_date")
	private String usageUtcFlightDate;

	@Column(name = "used_cabin_class")
	private String usedCabinClass;

	// bi-directional many-to-one association to AmadeusOldTaxStg
	@OneToMany(mappedBy = "amadeusRecordStg")
	private List<AmadeusOldTaxStaging> amadeusOldTaxStgs;

	// bi-directional many-to-one association to AmadeusRecordDetailStg
	@OneToMany(mappedBy = "amadeusRecordStg")
	private List<AmadeusRecordDetailStaging> amadeusRecordDetailStgs;

	// bi-directional many-to-one association to AmadeusRecordExchDetailStg
	@OneToMany(mappedBy = "amadeusRecordStg")
	private List<AmadeusRecordExchDetailStaging> amadeusRecordExchDetailStgs;

	public AmadeusRecordStaging() {
	}

	public int getAmadeusLoadId() {
		return this.amadeusLoadId;
	}

	public void setAmadeusLoadId(int amadeusLoadId) {
		this.amadeusLoadId = amadeusLoadId;
	}

	public String getAdditionalCollectionTotal() {
		return this.additionalCollectionTotal;
	}

	public void setAdditionalCollectionTotal(String additionalCollectionTotal) {
		this.additionalCollectionTotal = additionalCollectionTotal;
	}

	public String getAdditionalInformation() {
		return this.additionalInformation;
	}

	public void setAdditionalInformation(String additionalInformation) {
		this.additionalInformation = additionalInformation;
	}

	public String getAgencyNumber() {
		return this.agencyNumber;
	}

	public void setAgencyNumber(String agencyNumber) {
		this.agencyNumber = agencyNumber;
	}

	public String getAirlineChangePerformer() {
		return this.airlineChangePerformer;
	}

	public void setAirlineChangePerformer(String airlineChangePerformer) {
		this.airlineChangePerformer = airlineChangePerformer;
	}

	public String getAirlineCodeEmd() {
		return this.airlineCodeEmd;
	}

	public void setAirlineCodeEmd(String airlineCodeEmd) {
		this.airlineCodeEmd = airlineCodeEmd;
	}

	public String getAmountEnteredByAgent() {
		return this.amountEnteredByAgent;
	}

	public void setAmountEnteredByAgent(String amountEnteredByAgent) {
		this.amountEnteredByAgent = amountEnteredByAgent;
	}

	public String getApprovedCollectionCode() {
		return this.approvedCollectionCode;
	}

	public void setApprovedCollectionCode(String approvedCollectionCode) {
		this.approvedCollectionCode = approvedCollectionCode;
	}

	public String getApprovedCollectionCode2() {
		return this.approvedCollectionCode2;
	}

	public void setApprovedCollectionCode2(String approvedCollectionCode2) {
		this.approvedCollectionCode2 = approvedCollectionCode2;
	}

	public String getApprovedCollectionCode3() {
		return this.approvedCollectionCode3;
	}

	public void setApprovedCollectionCode3(String approvedCollectionCode3) {
		this.approvedCollectionCode3 = approvedCollectionCode3;
	}

	public String getAssociationStatus() {
		return this.associationStatus;
	}

	public void setAssociationStatus(String associationStatus) {
		this.associationStatus = associationStatus;
	}

	public String getBankersExchangeRate() {
		return this.bankersExchangeRate;
	}

	public void setBankersExchangeRate(String bankersExchangeRate) {
		this.bankersExchangeRate = bankersExchangeRate;
	}

	public String getBookingReference() {
		return this.bookingReference;
	}

	public void setBookingReference(String bookingReference) {
		this.bookingReference = bookingReference;
	}

	public String getCheckDigit() {
		return this.checkDigit;
	}

	public void setCheckDigit(String checkDigit) {
		this.checkDigit = checkDigit;
	}

	public String getCommissionAmount() {
		return this.commissionAmount;
	}

	public void setCommissionAmount(String commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	public String getCommissionRate() {
		return this.commissionRate;
	}

	public void setCommissionRate(String commissionRate) {
		this.commissionRate = commissionRate;
	}

	public String getCouponNumber() {
		return this.couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCouponRevenueIndicator() {
		return this.couponRevenueIndicator;
	}

	public void setCouponRevenueIndicator(String couponRevenueIndicator) {
		this.couponRevenueIndicator = couponRevenueIndicator;
	}

	public String getCouponSlsIndicator() {
		return this.couponSlsIndicator;
	}

	public void setCouponSlsIndicator(String couponSlsIndicator) {
		this.couponSlsIndicator = couponSlsIndicator;
	}

	public String getCouponValue() {
		return this.couponValue;
	}

	public void setCouponValue(String couponValue) {
		this.couponValue = couponValue;
	}

	public String getCurrOfAmtEnteredByAgent() {
		return this.currOfAmtEnteredByAgent;
	}

	public void setCurrOfAmtEnteredByAgent(String currOfAmtEnteredByAgent) {
		this.currOfAmtEnteredByAgent = currOfAmtEnteredByAgent;
	}

	public String getCurrencyOfAddlCollection() {
		return this.currencyOfAddlCollection;
	}

	public void setCurrencyOfAddlCollection(String currencyOfAddlCollection) {
		this.currencyOfAddlCollection = currencyOfAddlCollection;
	}

	public String getCurrencyOfCommissionAmount() {
		return this.currencyOfCommissionAmount;
	}

	public void setCurrencyOfCommissionAmount(String currencyOfCommissionAmount) {
		this.currencyOfCommissionAmount = currencyOfCommissionAmount;
	}

	public String getCurrencyOfNetFare() {
		return this.currencyOfNetFare;
	}

	public void setCurrencyOfNetFare(String currencyOfNetFare) {
		this.currencyOfNetFare = currencyOfNetFare;
	}

	public String getCurrencyOfReportedFare() {
		return this.currencyOfReportedFare;
	}

	public void setCurrencyOfReportedFare(String currencyOfReportedFare) {
		this.currencyOfReportedFare = currencyOfReportedFare;
	}

	public String getCurrencyOfTransTotalAmt() {
		return this.currencyOfTransTotalAmt;
	}

	public void setCurrencyOfTransTotalAmt(String currencyOfTransTotalAmt) {
		this.currencyOfTransTotalAmt = currencyOfTransTotalAmt;
	}

	public String getDocumentNumber() {
		return this.documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getDocumentType() {
		return this.documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getEbdChargeCurrency() {
		return this.ebdChargeCurrency;
	}

	public void setEbdChargeCurrency(String ebdChargeCurrency) {
		this.ebdChargeCurrency = ebdChargeCurrency;
	}

	public String getEbdChargeQualifier() {
		return this.ebdChargeQualifier;
	}

	public void setEbdChargeQualifier(String ebdChargeQualifier) {
		this.ebdChargeQualifier = ebdChargeQualifier;
	}

	public String getEbdRatePerUnit() {
		return this.ebdRatePerUnit;
	}

	public void setEbdRatePerUnit(String ebdRatePerUnit) {
		this.ebdRatePerUnit = ebdRatePerUnit;
	}

	public String getEbdTotalNoOfUnits() {
		return this.ebdTotalNoOfUnits;
	}

	public void setEbdTotalNoOfUnits(String ebdTotalNoOfUnits) {
		this.ebdTotalNoOfUnits = ebdTotalNoOfUnits;
	}

	public String getEbdUnitQualifier() {
		return this.ebdUnitQualifier;
	}

	public void setEbdUnitQualifier(String ebdUnitQualifier) {
		this.ebdUnitQualifier = ebdUnitQualifier;
	}

	public String getEmdDocumentAmount() {
		return this.emdDocumentAmount;
	}

	public void setEmdDocumentAmount(String emdDocumentAmount) {
		this.emdDocumentAmount = emdDocumentAmount;
	}

	public String getEmdDocumentAmountCurrency() {
		return this.emdDocumentAmountCurrency;
	}

	public void setEmdDocumentAmountCurrency(String emdDocumentAmountCurrency) {
		this.emdDocumentAmountCurrency = emdDocumentAmountCurrency;
	}

	public String getEndorsementRestrictionText() {
		return this.endorsementRestrictionText;
	}

	public void setEndorsementRestrictionText(String endorsementRestrictionText) {
		this.endorsementRestrictionText = endorsementRestrictionText;
	}

	public String getEquivalentFare() {
		return this.equivalentFare;
	}

	public void setEquivalentFare(String equivalentFare) {
		this.equivalentFare = equivalentFare;
	}

	public String getFareBasis() {
		return this.fareBasis;
	}

	public void setFareBasis(String fareBasis) {
		this.fareBasis = fareBasis;
	}

	public String getFareCalcModeIndicator() {
		return this.fareCalcModeIndicator;
	}

	public void setFareCalcModeIndicator(String fareCalcModeIndicator) {
		this.fareCalcModeIndicator = fareCalcModeIndicator;
	}

	public String getFareConstruction() {
		return this.fareConstruction;
	}

	public void setFareConstruction(String fareConstruction) {
		this.fareConstruction = fareConstruction;
	}

	public int getFileId() {
		return this.fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getFileSource() {
		return this.fileSource;
	}

	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}

	public String getFlightNumber() {
		return this.flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFormOfIdentVendorCode() {
		return this.formOfIdentVendorCode;
	}

	public void setFormOfIdentVendorCode(String formOfIdentVendorCode) {
		this.formOfIdentVendorCode = formOfIdentVendorCode;
	}

	public String getFormOfIdentificationNumber() {
		return this.formOfIdentificationNumber;
	}

	public void setFormOfIdentificationNumber(String formOfIdentificationNumber) {
		this.formOfIdentificationNumber = formOfIdentificationNumber;
	}

	public String getFormOfIdentificationType() {
		return this.formOfIdentificationType;
	}

	public void setFormOfIdentificationType(String formOfIdentificationType) {
		this.formOfIdentificationType = formOfIdentificationType;
	}

	public String getFormOfPayment() {
		return this.formOfPayment;
	}

	public void setFormOfPayment(String formOfPayment) {
		this.formOfPayment = formOfPayment;
	}

	public String getFormOfPayment2() {
		return this.formOfPayment2;
	}

	public void setFormOfPayment2(String formOfPayment2) {
		this.formOfPayment2 = formOfPayment2;
	}

	public String getFormOfPayment3() {
		return this.formOfPayment3;
	}

	public void setFormOfPayment3(String formOfPayment3) {
		this.formOfPayment3 = formOfPayment3;
	}

	public String getFrequentFlyerAirlineCode() {
		return this.frequentFlyerAirlineCode;
	}

	public void setFrequentFlyerAirlineCode(String frequentFlyerAirlineCode) {
		this.frequentFlyerAirlineCode = frequentFlyerAirlineCode;
	}

	public String getFrequentFlyerCustomerCode() {
		return this.frequentFlyerCustomerCode;
	}

	public void setFrequentFlyerCustomerCode(String frequentFlyerCustomerCode) {
		this.frequentFlyerCustomerCode = frequentFlyerCustomerCode;
	}

	public String getInConnectionCouponNo() {
		return this.inConnectionCouponNo;
	}

	public void setInConnectionCouponNo(String inConnectionCouponNo) {
		this.inConnectionCouponNo = inConnectionCouponNo;
	}

	public String getInConnectionDocNo() {
		return this.inConnectionDocNo;
	}

	public void setInConnectionDocNo(String inConnectionDocNo) {
		this.inConnectionDocNo = inConnectionDocNo;
	}

	public String getInternationalDomesticInd() {
		return this.internationalDomesticInd;
	}

	public void setInternationalDomesticInd(String internationalDomesticInd) {
		this.internationalDomesticInd = internationalDomesticInd;
	}

	public String getInternationalSaleIndicaor() {
		return this.internationalSaleIndicaor;
	}

	public void setInternationalSaleIndicaor(String internationalSaleIndicaor) {
		this.internationalSaleIndicaor = internationalSaleIndicaor;
	}

	public String getIssAirline() {
		return this.issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getIssueDate() {
		return this.issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getIssuingOfficeLocation() {
		return this.issuingOfficeLocation;
	}

	public void setIssuingOfficeLocation(String issuingOfficeLocation) {
		this.issuingOfficeLocation = issuingOfficeLocation;
	}

	public String getLocalDepartureDate() {
		return this.localDepartureDate;
	}

	public void setLocalDepartureDate(String localDepartureDate) {
		this.localDepartureDate = localDepartureDate;
	}

	public String getManualIndicator() {
		return this.manualIndicator;
	}

	public void setManualIndicator(String manualIndicator) {
		this.manualIndicator = manualIndicator;
	}

	public String getNetFare() {
		return this.netFare;
	}

	public void setNetFare(String netFare) {
		this.netFare = netFare;
	}

	public String getNetRemitIndicator() {
		return this.netRemitIndicator;
	}

	public void setNetRemitIndicator(String netRemitIndicator) {
		this.netRemitIndicator = netRemitIndicator;
	}

	public String getNetReportingIndicator() {
		return this.netReportingIndicator;
	}

	public void setNetReportingIndicator(String netReportingIndicator) {
		this.netReportingIndicator = netReportingIndicator;
	}

	public String getNonEndorsableIndicator() {
		return this.nonEndorsableIndicator;
	}

	public void setNonEndorsableIndicator(String nonEndorsableIndicator) {
		this.nonEndorsableIndicator = nonEndorsableIndicator;
	}

	public String getNonExchangeableAmount() {
		return this.nonExchangeableAmount;
	}

	public void setNonExchangeableAmount(String nonExchangeableAmount) {
		this.nonExchangeableAmount = nonExchangeableAmount;
	}

	public String getNonExchangeableAmtCurr() {
		return this.nonExchangeableAmtCurr;
	}

	public void setNonExchangeableAmtCurr(String nonExchangeableAmtCurr) {
		this.nonExchangeableAmtCurr = nonExchangeableAmtCurr;
	}

	public String getNonRefundableAmount() {
		return this.nonRefundableAmount;
	}

	public void setNonRefundableAmount(String nonRefundableAmount) {
		this.nonRefundableAmount = nonRefundableAmount;
	}

	public String getNonRefundableAmountCurr() {
		return this.nonRefundableAmountCurr;
	}

	public void setNonRefundableAmountCurr(String nonRefundableAmountCurr) {
		this.nonRefundableAmountCurr = nonRefundableAmountCurr;
	}

	public String getNonRefundableIndicator() {
		return this.nonRefundableIndicator;
	}

	public void setNonRefundableIndicator(String nonRefundableIndicator) {
		this.nonRefundableIndicator = nonRefundableIndicator;
	}

	public String getNotValidAfterDate() {
		return this.notValidAfterDate;
	}

	public void setNotValidAfterDate(String notValidAfterDate) {
		this.notValidAfterDate = notValidAfterDate;
	}

	public String getNotValidBeforeDate() {
		return this.notValidBeforeDate;
	}

	public void setNotValidBeforeDate(String notValidBeforeDate) {
		this.notValidBeforeDate = notValidBeforeDate;
	}

	public String getOldApprovedCollectionCode1() {
		return this.oldApprovedCollectionCode1;
	}

	public void setOldApprovedCollectionCode1(String oldApprovedCollectionCode1) {
		this.oldApprovedCollectionCode1 = oldApprovedCollectionCode1;
	}

	public String getOldApprovedCollectionCode2() {
		return this.oldApprovedCollectionCode2;
	}

	public void setOldApprovedCollectionCode2(String oldApprovedCollectionCode2) {
		this.oldApprovedCollectionCode2 = oldApprovedCollectionCode2;
	}

	public String getOldApprovedCollectionCode3() {
		return this.oldApprovedCollectionCode3;
	}

	public void setOldApprovedCollectionCode3(String oldApprovedCollectionCode3) {
		this.oldApprovedCollectionCode3 = oldApprovedCollectionCode3;
	}

	public String getOldFormOfPayment() {
		return this.oldFormOfPayment;
	}

	public void setOldFormOfPayment(String oldFormOfPayment) {
		this.oldFormOfPayment = oldFormOfPayment;
	}

	public String getOldFormOfPayment2() {
		return this.oldFormOfPayment2;
	}

	public void setOldFormOfPayment2(String oldFormOfPayment2) {
		this.oldFormOfPayment2 = oldFormOfPayment2;
	}

	public String getOldFormOfPayment3() {
		return this.oldFormOfPayment3;
	}

	public void setOldFormOfPayment3(String oldFormOfPayment3) {
		this.oldFormOfPayment3 = oldFormOfPayment3;
	}

	public String getOriginalEmdDocNumber1() {
		return this.originalEmdDocNumber1;
	}

	public void setOriginalEmdDocNumber1(String originalEmdDocNumber1) {
		this.originalEmdDocNumber1 = originalEmdDocNumber1;
	}

	public String getOriginalEmdDocNumber2() {
		return this.originalEmdDocNumber2;
	}

	public void setOriginalEmdDocNumber2(String originalEmdDocNumber2) {
		this.originalEmdDocNumber2 = originalEmdDocNumber2;
	}

	public String getOriginalEmdDocNumber3() {
		return this.originalEmdDocNumber3;
	}

	public void setOriginalEmdDocNumber3(String originalEmdDocNumber3) {
		this.originalEmdDocNumber3 = originalEmdDocNumber3;
	}

	public String getOriginalEmdDocNumber4() {
		return this.originalEmdDocNumber4;
	}

	public void setOriginalEmdDocNumber4(String originalEmdDocNumber4) {
		this.originalEmdDocNumber4 = originalEmdDocNumber4;
	}

	public String getOriginalEmdDocNumber5() {
		return this.originalEmdDocNumber5;
	}

	public void setOriginalEmdDocNumber5(String originalEmdDocNumber5) {
		this.originalEmdDocNumber5 = originalEmdDocNumber5;
	}

	public String getOriginalEmdDocNumber6() {
		return this.originalEmdDocNumber6;
	}

	public void setOriginalEmdDocNumber6(String originalEmdDocNumber6) {
		this.originalEmdDocNumber6 = originalEmdDocNumber6;
	}

	public String getOriginalEmdDocNumber7() {
		return this.originalEmdDocNumber7;
	}

	public void setOriginalEmdDocNumber7(String originalEmdDocNumber7) {
		this.originalEmdDocNumber7 = originalEmdDocNumber7;
	}

	public String getOriginalIssueInformation() {
		return this.originalIssueInformation;
	}

	public void setOriginalIssueInformation(String originalIssueInformation) {
		this.originalIssueInformation = originalIssueInformation;
	}

	public String getPassengerName() {
		return this.passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getPaymentCurrency() {
		return this.paymentCurrency;
	}

	public void setPaymentCurrency(String paymentCurrency) {
		this.paymentCurrency = paymentCurrency;
	}

	public String getPenaltyRestrictionIndicator() {
		return this.penaltyRestrictionIndicator;
	}

	public void setPenaltyRestrictionIndicator(String penaltyRestrictionIndicator) {
		this.penaltyRestrictionIndicator = penaltyRestrictionIndicator;
	}

	public String getPresentCreditCardIndicator() {
		return this.presentCreditCardIndicator;
	}

	public void setPresentCreditCardIndicator(String presentCreditCardIndicator) {
		this.presentCreditCardIndicator = presentCreditCardIndicator;
	}

	public String getReasonForIssuanceCode() {
		return this.reasonForIssuanceCode;
	}

	public void setReasonForIssuanceCode(String reasonForIssuanceCode) {
		this.reasonForIssuanceCode = reasonForIssuanceCode;
	}

	public String getReasonForIssuanceSubCode() {
		return this.reasonForIssuanceSubCode;
	}

	public void setReasonForIssuanceSubCode(String reasonForIssuanceSubCode) {
		this.reasonForIssuanceSubCode = reasonForIssuanceSubCode;
	}

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getReportedFare() {
		return this.reportedFare;
	}

	public void setReportedFare(String reportedFare) {
		this.reportedFare = reportedFare;
	}

	public String getRevenueAttributionNumber() {
		return this.revenueAttributionNumber;
	}

	public void setRevenueAttributionNumber(String revenueAttributionNumber) {
		this.revenueAttributionNumber = revenueAttributionNumber;
	}

	public String getSettlementAuthorizationCode() {
		return this.settlementAuthorizationCode;
	}

	public void setSettlementAuthorizationCode(String settlementAuthorizationCode) {
		this.settlementAuthorizationCode = settlementAuthorizationCode;
	}

	public String getSettlementAuthorizationEmd() {
		return this.settlementAuthorizationEmd;
	}

	public void setSettlementAuthorizationEmd(String settlementAuthorizationEmd) {
		this.settlementAuthorizationEmd = settlementAuthorizationEmd;
	}

	public String getSoldDestinationCode() {
		return this.soldDestinationCode;
	}

	public void setSoldDestinationCode(String soldDestinationCode) {
		this.soldDestinationCode = soldDestinationCode;
	}

	public String getSoldLocalDepartDate() {
		return this.soldLocalDepartDate;
	}

	public void setSoldLocalDepartDate(String soldLocalDepartDate) {
		this.soldLocalDepartDate = soldLocalDepartDate;
	}

	public String getSoldMarketingCarrier() {
		return this.soldMarketingCarrier;
	}

	public void setSoldMarketingCarrier(String soldMarketingCarrier) {
		this.soldMarketingCarrier = soldMarketingCarrier;
	}

	public String getSoldMarketingFlightNo() {
		return this.soldMarketingFlightNo;
	}

	public void setSoldMarketingFlightNo(String soldMarketingFlightNo) {
		this.soldMarketingFlightNo = soldMarketingFlightNo;
	}

	public String getSoldOperatingCarrier() {
		return this.soldOperatingCarrier;
	}

	public void setSoldOperatingCarrier(String soldOperatingCarrier) {
		this.soldOperatingCarrier = soldOperatingCarrier;
	}

	public String getSoldOperatingFlightNo() {
		return this.soldOperatingFlightNo;
	}

	public void setSoldOperatingFlightNo(String soldOperatingFlightNo) {
		this.soldOperatingFlightNo = soldOperatingFlightNo;
	}

	public String getSoldOriginCode() {
		return this.soldOriginCode;
	}

	public void setSoldOriginCode(String soldOriginCode) {
		this.soldOriginCode = soldOriginCode;
	}

	public String getStaffResEntitlement() {
		return this.staffResEntitlement;
	}

	public void setStaffResEntitlement(String staffResEntitlement) {
		this.staffResEntitlement = staffResEntitlement;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTicketingModeIndicator() {
		return this.ticketingModeIndicator;
	}

	public void setTicketingModeIndicator(String ticketingModeIndicator) {
		this.ticketingModeIndicator = ticketingModeIndicator;
	}

	public String getTourCode() {
		return this.tourCode;
	}

	public void setTourCode(String tourCode) {
		this.tourCode = tourCode;
	}

	public String getTransactionTotalAmount() {
		return this.transactionTotalAmount;
	}

	public void setTransactionTotalAmount(String transactionTotalAmount) {
		this.transactionTotalAmount = transactionTotalAmount;
	}

	public String getUsageAirline() {
		return this.usageAirline;
	}

	public void setUsageAirline(String usageAirline) {
		this.usageAirline = usageAirline;
	}

	public String getUsageDestinationCode() {
		return this.usageDestinationCode;
	}

	public void setUsageDestinationCode(String usageDestinationCode) {
		this.usageDestinationCode = usageDestinationCode;
	}

	public String getUsageDestinationCodeEmd() {
		return this.usageDestinationCodeEmd;
	}

	public void setUsageDestinationCodeEmd(String usageDestinationCodeEmd) {
		this.usageDestinationCodeEmd = usageDestinationCodeEmd;
	}

	public String getUsageDocNumber() {
		return this.usageDocNumber;
	}

	public void setUsageDocNumber(String usageDocNumber) {
		this.usageDocNumber = usageDocNumber;
	}

	public String getUsageEmdDate() {
		return this.usageEmdDate;
	}

	public void setUsageEmdDate(String usageEmdDate) {
		this.usageEmdDate = usageEmdDate;
	}

	public String getUsageLocalFlightDate() {
		return this.usageLocalFlightDate;
	}

	public void setUsageLocalFlightDate(String usageLocalFlightDate) {
		this.usageLocalFlightDate = usageLocalFlightDate;
	}

	public String getUsageMarketingCarrierCode() {
		return this.usageMarketingCarrierCode;
	}

	public void setUsageMarketingCarrierCode(String usageMarketingCarrierCode) {
		this.usageMarketingCarrierCode = usageMarketingCarrierCode;
	}

	public String getUsageOperatingCarrier() {
		return this.usageOperatingCarrier;
	}

	public void setUsageOperatingCarrier(String usageOperatingCarrier) {
		this.usageOperatingCarrier = usageOperatingCarrier;
	}

	public String getUsageOperatingFlightNumber() {
		return this.usageOperatingFlightNumber;
	}

	public void setUsageOperatingFlightNumber(String usageOperatingFlightNumber) {
		this.usageOperatingFlightNumber = usageOperatingFlightNumber;
	}

	public String getUsageOperatingFlightSuffix() {
		return this.usageOperatingFlightSuffix;
	}

	public void setUsageOperatingFlightSuffix(String usageOperatingFlightSuffix) {
		this.usageOperatingFlightSuffix = usageOperatingFlightSuffix;
	}

	public String getUsageOriginCode() {
		return this.usageOriginCode;
	}

	public void setUsageOriginCode(String usageOriginCode) {
		this.usageOriginCode = usageOriginCode;
	}

	public String getUsageOriginCodeEmd() {
		return this.usageOriginCodeEmd;
	}

	public void setUsageOriginCodeEmd(String usageOriginCodeEmd) {
		this.usageOriginCodeEmd = usageOriginCodeEmd;
	}

	public String getUsagePerformer() {
		return this.usagePerformer;
	}

	public void setUsagePerformer(String usagePerformer) {
		this.usagePerformer = usagePerformer;
	}

	public String getUsageType() {
		return this.usageType;
	}

	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}

	public String getUsageUtcFlightDate() {
		return this.usageUtcFlightDate;
	}

	public void setUsageUtcFlightDate(String usageUtcFlightDate) {
		this.usageUtcFlightDate = usageUtcFlightDate;
	}

	public String getUsedCabinClass() {
		return this.usedCabinClass;
	}

	public void setUsedCabinClass(String usedCabinClass) {
		this.usedCabinClass = usedCabinClass;
	}

	public List<AmadeusOldTaxStaging> getAmadeusOldTaxStgs() {
		return this.amadeusOldTaxStgs;
	}

	public void setAmadeusOldTaxStgs(List<AmadeusOldTaxStaging> amadeusOldTaxStgs) {
		this.amadeusOldTaxStgs = amadeusOldTaxStgs;
	}

	public AmadeusOldTaxStaging addAmadeusOldTaxStg(AmadeusOldTaxStaging amadeusOldTaxStg) {
		getAmadeusOldTaxStgs().add(amadeusOldTaxStg);
		amadeusOldTaxStg.setAmadeusRecordStg(this);

		return amadeusOldTaxStg;
	}

	public AmadeusOldTaxStaging removeAmadeusOldTaxStg(AmadeusOldTaxStaging amadeusOldTaxStg) {
		getAmadeusOldTaxStgs().remove(amadeusOldTaxStg);
		amadeusOldTaxStg.setAmadeusRecordStg(null);

		return amadeusOldTaxStg;
	}

	public List<AmadeusRecordDetailStaging> getAmadeusRecordDetailStgs() {
		return this.amadeusRecordDetailStgs;
	}

	public void setAmadeusRecordDetailStgs(List<AmadeusRecordDetailStaging> amadeusRecordDetailStgs) {
		this.amadeusRecordDetailStgs = amadeusRecordDetailStgs;
	}

	public AmadeusRecordDetailStaging addAmadeusRecordDetailStg(AmadeusRecordDetailStaging amadeusRecordDetailStg) {
		getAmadeusRecordDetailStgs().add(amadeusRecordDetailStg);
		amadeusRecordDetailStg.setAmadeusRecordStg(this);

		return amadeusRecordDetailStg;
	}

	public AmadeusRecordDetailStaging removeAmadeusRecordDetailStg(AmadeusRecordDetailStaging amadeusRecordDetailStg) {
		getAmadeusRecordDetailStgs().remove(amadeusRecordDetailStg);
		amadeusRecordDetailStg.setAmadeusRecordStg(null);

		return amadeusRecordDetailStg;
	}

	public List<AmadeusRecordExchDetailStaging> getAmadeusRecordExchDetailStgs() {
		return this.amadeusRecordExchDetailStgs;
	}

	public void setAmadeusRecordExchDetailStgs(List<AmadeusRecordExchDetailStaging> amadeusRecordExchDetailStgs) {
		this.amadeusRecordExchDetailStgs = amadeusRecordExchDetailStgs;
	}

	public AmadeusRecordExchDetailStaging addAmadeusRecordExchDetailStg(
			AmadeusRecordExchDetailStaging amadeusRecordExchDetailStg) {
		getAmadeusRecordExchDetailStgs().add(amadeusRecordExchDetailStg);
		amadeusRecordExchDetailStg.setAmadeusRecordStg(this);

		return amadeusRecordExchDetailStg;
	}

	public AmadeusRecordExchDetailStaging removeAmadeusRecordExchDetailStg(
			AmadeusRecordExchDetailStaging amadeusRecordExchDetailStg) {
		getAmadeusRecordExchDetailStgs().remove(amadeusRecordExchDetailStg);
		amadeusRecordExchDetailStg.setAmadeusRecordStg(null);

		return amadeusRecordExchDetailStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {

		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		AmadeusRecordStagingLayout amadeusRecordStagingLayout = new AmadeusRecordStagingLayout();
		tokenizer.setColumns(amadeusRecordStagingLayout.getColumns());
		tokenizer.setNames(amadeusRecordStagingLayout.getNames());
		return tokenizer;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		BeanWrapperFieldSetMapper<AmadeusEtlRecord> fieldSetMapper = new BeanWrapperFieldSetMapper<AmadeusEtlRecord>();
		fieldSetMapper.setTargetType(AmadeusRecordStaging.class);
		return fieldSetMapper;
	}

	



	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		return new AmadeusRecordStagingProcessor();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		return new AmadeusRecordStagingWriter();
	}

}