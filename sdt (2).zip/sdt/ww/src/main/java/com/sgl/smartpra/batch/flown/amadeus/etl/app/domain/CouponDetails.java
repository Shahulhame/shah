package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import javax.persistence.Transient;

public class CouponDetails {

	private String issAirline;

	private String documentNumber;

	private String couponNumber;

	@Transient
	private String coupons;

	public String getIssAirline() {
		return issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getCoupons() {
		return coupons;
	}

	public void setCoupons(String coupons) {
		// Patch to support prefix/sufix blank spaces igored by the mapper parsing
        int strLen=coupons.length();
        String negOrSpaceChar = coupons.substring(strLen-1, strLen);
        if(!(negOrSpaceChar.equals(" ") || negOrSpaceChar.equals("-"))) coupons = coupons +" ";
        if((coupons.length() % 67)!=0) coupons = " "+coupons;
        this.coupons = coupons;
		this.coupons = coupons;
	}

	/*private ArrayList<CouponDetails> getESALTaxDetailList() { 
        ArrayList<CouponDetails> couponDetailsList = new ArrayList<CouponDetails>();
        String couponDetailStr = this.getCoupons();
        int couponCunt = couponDetailStr.length()/67;
        CouponDetails couponRecord;
        for(int i=0;i<couponCunt;i++) {
        	
        	couponRecord = new CouponDetails();
        	couponRecord.setIssAirline(this.getIssAirline());
        	couponRecord.setDocumentNumber(this.getDocumentNumber());
        	couponRecord.setCouponNumber(this.getCouponNumber());
        	//couponRecord.setCoupons(couponDetailStr);
        	couponRecord.setCouponNumber(couponDetailStr.substring((i*67), (i*67)+4));
        	//couponRecord.set(convStrToBigDec(taxDetailStr.substring((i*45)+3, (i*45)+17)));
               //taxRec.setTaxAmountAccepted(convStrToBigDec(taxDetailStr.substring((i*45)+17, (i*45)+31)));
               //taxRec.setTaxAmountDifference(convStrToBigDec(taxDetailStr.substring((i*45)+31, (i*45)+45)));
             // eSALTaxDetailList.add(taxRec);
        }
        //return eSALTaxDetailList;
 }

 private BigDecimal convStrToBigDec(String inNumStr) {
        int strLen=inNumStr.length();
        String numStr = inNumStr.substring(0, strLen-1).trim();
        String negChar = inNumStr.substring(strLen-1, strLen);
        inNumStr = inNumStr.trim();
        BigDecimal bigDecimalVal = new BigDecimal(numStr);
        if(negChar.equals("-")) {
              bigDecimalVal = bigDecimalVal.negate();
        }
        return bigDecimalVal;
 }
*/

	
  


	
}
