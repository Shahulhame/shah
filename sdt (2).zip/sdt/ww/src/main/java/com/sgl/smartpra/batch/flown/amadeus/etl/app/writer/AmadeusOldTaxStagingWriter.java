package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusOldTaxStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusOldTaxStagingRepository;

@Component
public class AmadeusOldTaxStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusOldTaxStaging> {

	@Autowired
	private AmadeusOldTaxStagingRepository AmadeusOldTaxRepository;

	@Override
	public void write(List<? extends AmadeusOldTaxStaging> amadeusOldTax) throws Exception {


	}

}
