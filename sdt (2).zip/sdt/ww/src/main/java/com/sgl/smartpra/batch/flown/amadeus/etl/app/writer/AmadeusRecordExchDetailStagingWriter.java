package com.sgl.smartpra.batch.flown.amadeus.etl.app.writer;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusEtlRecord;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusNewTaxStaging;
import com.sgl.smartpra.batch.flown.amadeus.etl.app.repository.AmadeusRecordExchDetailStagingRepository;

@Component
public class AmadeusRecordExchDetailStagingWriter<T extends AmadeusEtlRecord> implements ItemWriter<AmadeusNewTaxStaging> {

	@Autowired
	private AmadeusRecordExchDetailStagingRepository amadeusNewTaxRepository;

	@Override
	public void write(List<? extends AmadeusNewTaxStaging> amadeusEtlheadera) throws Exception {
		
		


	}

}
