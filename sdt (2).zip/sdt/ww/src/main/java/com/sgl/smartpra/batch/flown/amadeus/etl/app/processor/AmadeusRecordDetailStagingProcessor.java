package com.sgl.smartpra.batch.flown.amadeus.etl.app.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sgl.smartpra.batch.flown.amadeus.etl.app.domain.AmadeusRecordDetailStaging;

@SuppressWarnings("serial")
@Component
@Scope(value = "step")
public class AmadeusRecordDetailStagingProcessor extends AmadeusProcessor
		implements ItemProcessor<AmadeusRecordDetailStaging, AmadeusRecordDetailStaging> {

	@Override
	public AmadeusRecordDetailStaging process(AmadeusRecordDetailStaging amadeusRecordDetailStaging) throws Exception {
		super.process(amadeusRecordDetailStaging);

		return amadeusRecordDetailStaging;
	}
}
