package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;
/*package com.sgl.smartpra.flown.amadeus.etl.app.domain;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class AmadeusLogMapper implements FieldSetMapper<AmadeusLineMapper>{

	@Override
	public AmadeusLineMapper mapFieldSet(FieldSet fieldSet) throws BindException {
		for (int i = 0; i < 16; i++) {
			AmadeusLineMapper amadeusLineMapper=new AmadeusLineMapper();
			Map<String, Integer> list = new LinkedHashMap<>();	
			for (Entry<String, Integer> entry : list.entrySet()) {
				
				amadeusLineMapper.setAmadeusRecordDetailStaging(fieldSet.readString("couponNumber"));
				
			}
		}
		
		
		return null;
	}
	
	

}
*/