package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import java.io.Serializable;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

/**
 * The persistent class for the amadeus_record_exch_detail_stg database table.
 * 
 */

public class AmadeusRecordExchDetail extends AmadeusEtlRecord implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private int amdsRecExcLoadId;

	
	private String couponNumber;

	private String disruptionInd;

	private String documentNumber;

	private String issAirline;

	private String marketingCarrierCode;

	private String oldCouponNumber;

	private String oldDestAirportCode;

	private String oldDocumentNumber;

	private String oldFlightDate;

	private String oldFlightDeptTime;

	private String oldFlightNo;

	private String oldIssAirline;

	private String oldOrigAirportCode;

	private String oldRbd;

	private String stopOverCode;

	private String usageDocumentNumber;

	
	private AmadeusRecordStaging amadeusRecordStg;

	

	public int getAmdsRecExcLoadId() {
		return amdsRecExcLoadId;
	}

	public void setAmdsRecExcLoadId(int amdsRecExcLoadId) {
		this.amdsRecExcLoadId = amdsRecExcLoadId;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getDisruptionInd() {
		return disruptionInd;
	}

	public void setDisruptionInd(String disruptionInd) {
		this.disruptionInd = disruptionInd;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getIssAirline() {
		return issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getMarketingCarrierCode() {
		return marketingCarrierCode;
	}

	public void setMarketingCarrierCode(String marketingCarrierCode) {
		this.marketingCarrierCode = marketingCarrierCode;
	}

	public String getOldCouponNumber() {
		return oldCouponNumber;
	}

	public void setOldCouponNumber(String oldCouponNumber) {
		this.oldCouponNumber = oldCouponNumber;
	}

	public String getOldDestAirportCode() {
		return oldDestAirportCode;
	}

	public void setOldDestAirportCode(String oldDestAirportCode) {
		this.oldDestAirportCode = oldDestAirportCode;
	}

	public String getOldDocumentNumber() {
		return oldDocumentNumber;
	}

	public void setOldDocumentNumber(String oldDocumentNumber) {
		this.oldDocumentNumber = oldDocumentNumber;
	}

	public String getOldFlightDate() {
		return oldFlightDate;
	}

	public void setOldFlightDate(String oldFlightDate) {
		this.oldFlightDate = oldFlightDate;
	}

	public String getOldFlightDeptTime() {
		return oldFlightDeptTime;
	}

	public void setOldFlightDeptTime(String oldFlightDeptTime) {
		this.oldFlightDeptTime = oldFlightDeptTime;
	}

	public String getOldFlightNo() {
		return oldFlightNo;
	}

	public void setOldFlightNo(String oldFlightNo) {
		this.oldFlightNo = oldFlightNo;
	}

	public String getOldIssAirline() {
		return oldIssAirline;
	}

	public void setOldIssAirline(String oldIssAirline) {
		this.oldIssAirline = oldIssAirline;
	}

	public String getOldOrigAirportCode() {
		return oldOrigAirportCode;
	}

	public void setOldOrigAirportCode(String oldOrigAirportCode) {
		this.oldOrigAirportCode = oldOrigAirportCode;
	}

	public String getOldRbd() {
		return oldRbd;
	}

	public void setOldRbd(String oldRbd) {
		this.oldRbd = oldRbd;
	}

	public String getStopOverCode() {
		return stopOverCode;
	}

	public void setStopOverCode(String stopOverCode) {
		this.stopOverCode = stopOverCode;
	}

	public String getUsageDocumentNumber() {
		return usageDocumentNumber;
	}

	public void setUsageDocumentNumber(String usageDocumentNumber) {
		this.usageDocumentNumber = usageDocumentNumber;
	}

	public AmadeusRecordStaging getAmadeusRecordStg() {
		return amadeusRecordStg;
	}

	public void setAmadeusRecordStg(AmadeusRecordStaging amadeusRecordStg) {
		this.amadeusRecordStg = amadeusRecordStg;
	}

	@Override
	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemProcessor<? extends AmadeusEtlRecord, ? extends AmadeusEtlRecord> processor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemWriter<? super AmadeusEtlRecord> writer() {
		// TODO Auto-generated method stub
		return null;
	}

}