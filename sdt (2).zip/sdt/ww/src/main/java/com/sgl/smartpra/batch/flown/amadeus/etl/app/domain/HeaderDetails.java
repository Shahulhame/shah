package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.LineTokenizer;

public class HeaderDetails {

	private String recordType;

	private String fileId;

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	@Override
	public String toString() {
		return "HeaderDetails [recordType=" + recordType + ", fileId=" + fileId + "]";
	}

	public LineTokenizer lineTokenizer() {
		// TODO Auto-generated method stub
		return null;
	}

	public FieldSetMapper<AmadeusEtlRecord> fieldSetMapper() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
