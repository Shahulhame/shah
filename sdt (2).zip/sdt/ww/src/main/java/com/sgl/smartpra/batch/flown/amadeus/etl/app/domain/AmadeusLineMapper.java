package com.sgl.smartpra.batch.flown.amadeus.etl.app.domain;

import java.util.List;

public class AmadeusLineMapper {
	
	
	private String issAirline;

	private String documentNumber;

	private String couponNumber;
	
	private  List<AmadeusRecordDetailStaging> amadeusRecordDetailStaging;

	public String getIssAirline() {
		return issAirline;
	}

	public void setIssAirline(String issAirline) {
		this.issAirline = issAirline;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public String getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(String couponNumber) {
		this.couponNumber = couponNumber;
	}

	public List<AmadeusRecordDetailStaging> getAmadeusRecordDetailStaging() {
		return amadeusRecordDetailStaging;
	}

	public void setAmadeusRecordDetailStaging(List<AmadeusRecordDetailStaging> amadeusRecordDetailStaging) {
		this.amadeusRecordDetailStaging = amadeusRecordDetailStaging;
	}

	
	
	
	
	
	

}
